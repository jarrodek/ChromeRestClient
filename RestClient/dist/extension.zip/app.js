window.arc.app.analytics.init();

window.Polymer = window.Polymer || {};
window.Polymer.dom = 'shadow';

window.addEventListener('load', function() {
  window.arc.app.arc.checkCompatybility();
});
