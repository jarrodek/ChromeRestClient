// Production steps of ECMA-262, Edition 6, 22.1.2.1
// Reference: https://people.mozilla.org/~jorendorff/es6-draft.html#sec-array.from
if (!Array.from) {
  Array.from = (function() {
    var toStr = Object.prototype.toString;
    var isCallable = function(fn) {
      return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
    };
    var toInteger = function(value) {
      var number = Number(value);
      if (isNaN(number)) {
        return 0;
      }
      if (number === 0 || !isFinite(number)) {
        return number;
      }
      return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
    };
    var maxSafeInteger = Math.pow(2, 53) - 1;
    var toLength = function(value) {
      var len = toInteger(value);
      return Math.min(Math.max(len, 0), maxSafeInteger);
    };

    // The length property of the from method is 1.
    return function from(arrayLike /*, mapFn, thisArg */) {
      // 1. Let C be the this value.
      var C = this;

      // 2. Let items be ToObject(arrayLike).
      var items = Object(arrayLike);

      // 3. ReturnIfAbrupt(items).
      if (arrayLike === null) {
        throw new TypeError('Array.from requires an array-like object - not null or undefined');
      }

      // 4. If mapfn is undefined, then let mapping be false.
      var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
      var T;
      if (typeof mapFn !== 'undefined') {
        // 5. else
        // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
        if (!isCallable(mapFn)) {
          throw new TypeError('Array.from: when provided, the second argument must be a function');
        }

        // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
        if (arguments.length > 2) {
          T = arguments[2];
        }
      }

      // 10. Let lenValue be Get(items, "length").
      // 11. Let len be ToLength(lenValue).
      var len = toLength(items.length);

      // 13. If IsConstructor(C) is true, then
      // 13. a. Let A be the result of calling the [[Construct]] internal method of C with an 
      //     argument list containing the single item len.
      // 14. a. Else, Let A be ArrayCreate(len).
      var A = isCallable(C) ? Object(new C(len)) : new Array(len);

      // 16. Let k be 0.
      var k = 0;
      // 17. Repeat, while k < len… (also steps a - h)
      var kValue;
      while (k < len) {
        kValue = items[k];
        if (mapFn) {
          A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
        } else {
          A[k] = kValue;
        }
        k += 1;
      }
      // 18. Let putStatus be Put(A, "length", len, true).
      A.length = len;
      // 20. Return A.
      return A;
    };
  }());
}

!function(n,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):n.Dexie=t()}(this,function(){"use strict";function n(n,t){return"object"!=typeof t&&(t=t()),R(t).forEach(function(e){n[e]=t[e]}),n}function t(t){return{from:function(e){return t.prototype=Object.create(e.prototype),t.prototype.constructor=t,{extend:function(r){n(t.prototype,"object"!=typeof r?r(e.prototype):r)}}}}}function e(n,t,e){return U.call(n,t,e)}function r(n,t){return t(n)}function o(a,h){function y(){qn.on("versionchange",function(n){qn.close(),qn.on("error").fire(new kn("Database version changed by other database connection."))})}function b(n){this._cfg={version:n,storesSource:null,dbschema:{},tables:{},contentUpgrade:null},this.stores({})}function P(n,t,o,i){if(0===n){R(On).forEach(function(n){U(t,n,On[n].primKey,On[n].indexes)});var u=qn._createTransaction(Fn,jn,On);u.idbtrans=t,u.idbtrans.onerror=j(o,["populating database"]),u.on("error").subscribe(o),J.newPSD(function(){J.PSD.trans=u;try{qn.on("populate").fire(u)}catch(n){i.onerror=t.onerror=function(n){n.preventDefault()};try{t.abort()}catch(e){}t.db.close(),o(n)}})}else{var c=[],a=En.filter(function(t){return t._cfg.version===n})[0];if(!a)throw new kn("Dexie specification of currently installed DB version is missing");On=qn._dbSchema=a._cfg.dbschema;var s=!1,f=En.filter(function(t){return t._cfg.version>n});f.forEach(function(n){var i=On,u=n._cfg.dbschema;wn(i,t),wn(u,t),On=qn._dbSchema=u;var a=O(i,u);a.add.forEach(function(n){c.push(function(t,e){U(t,n[0],n[1].primKey,n[1].indexes),e()})}),a.change.forEach(function(n){if(n.recreate)throw new kn("Not yet support for changing primary key");c.push(function(t,e){var r=t.objectStore(n.name);n.add.forEach(function(n){Q(r,n)}),n.change.forEach(function(n){r.deleteIndex(n.name),Q(r,n)}),n.del.forEach(function(n){r.deleteIndex(n)}),e()})}),n._cfg.contentUpgrade&&c.push(function(t,i){s=!0;var c=qn._createTransaction(Fn,e(t.db.objectStoreNames),u);c.idbtrans=t;var a=0;c._promise=r(c._promise,function(n){return function(t,e,r){function o(n){return function(){n.apply(this,arguments),0===--a&&i()}}return++a,n.call(this,t,function(n,t,r){arguments[0]=o(n),arguments[1]=o(t),e.apply(this,arguments)},r)}}),t.onerror=j(o,["running upgrader function for version",n._cfg.version]),c.on("error").subscribe(o),n._cfg.contentUpgrade(c),0===a&&i()}),s&&bn()||c.push(function(n,t){G(u,n),t()})});var h=function(){try{c.length?c.shift()(t,h):W(On,t)}catch(n){i.onerror=t.onerror=function(n){n.preventDefault()};try{t.abort()}catch(e){}t.db.close(),o(n)}};h()}}function O(n,t){var e={del:[],add:[],change:[]};for(var r in n)t[r]||e.del.push(r);for(var r in t){var o=n[r],i=t[r];if(o){var u={name:r,def:t[r],recreate:!1,del:[],add:[],change:[]};if(o.primKey.src!==i.primKey.src)u.recreate=!0,e.change.push(u);else{var c=o.indexes.reduce(function(n,t){return n[t.name]=t,n},{}),a=i.indexes.reduce(function(n,t){return n[t.name]=t,n},{});for(var s in c)a[s]||u.del.push(s);for(var s in a){var f=c[s],h=a[s];f?f.src!==h.src&&u.change.push(h):u.add.push(h)}(u.recreate||u.del.length>0||u.add.length>0||u.change.length>0)&&e.change.push(u)}}else e.add.push([r,i])}return e}function U(n,t,e,r){var o=n.db.createObjectStore(t,e.keyPath?{keyPath:e.keyPath,autoIncrement:e.auto}:{autoIncrement:e.auto});return r.forEach(function(n){Q(o,n)}),o}function W(n,t){R(n).forEach(function(e){t.db.objectStoreNames.contains(e)||U(t,e,n[e].primKey,n[e].indexes)})}function G(n,t){for(var e=0;e<t.db.objectStoreNames.length;++e){var r=t.db.objectStoreNames[e];null!==n[r]&&void 0!==n[r]||t.db.deleteObjectStore(r)}}function Q(n,t){n.createIndex(t.name,t.keyPath,{unique:t.unique,multiEntry:t.multi})}function X(n,t){throw new kn("Table "+t[0]+" not part of transaction. Original Scope Function Source: "+o.Promise.PSD.trans.scopeFunc.toString())}function Z(n,t,e,r){this.name=n,this.schema=e,this.hook=Cn[n]?Cn[n].hook:v(null,{creating:[s,i],reading:[c,u],updating:[f,i],deleting:[d,i]}),this._tpf=t,this._collClass=r||en}function $(n,t,e,r){Z.call(this,n,t,e,r||rn)}function nn(n,t,e,r){function o(n,t,e,r){return i._promise(n,e,r)}var i=this;this.db=qn,this.mode=n,this.storeNames=t,this.idbtrans=null,this.on=v(this,["complete","error"],"abort"),this._reculock=0,this._blockedFuncs=[],this._psd=null,this.active=!0,this._dbschema=e,r&&(this.parent=r),this._tpf=o,this.tables=Object.create(Tn);for(var u=t.length-1;-1!==u;--u){var c=t[u],a=qn._tableFactory(n,e[c],o);this.tables[c]=a,this[c]||(this[c]=a)}}function tn(n,t,e){this._ctx={table:n,index:":id"===t?null:t,collClass:n._collClass,or:e}}function en(n,t){var e=null,r=null;if(t)try{e=t()}catch(o){try{throw new kn(o)}catch(i){r=i}}var u=n._ctx;this._ctx={table:u.table,index:u.index,isPrimKey:!u.index||u.table.schema.primKey.keyPath&&u.index===u.table.schema.primKey.name,range:e,op:"openCursor",dir:"next",unique:"",algorithm:null,filter:null,isMatch:null,offset:0,limit:1/0,error:r,or:u.or}}function rn(){en.apply(this,arguments)}function on(n,t){return n._cfg.version-t._cfg.version}function un(n,t,e,r,o,i){e.forEach(function(e){var u=qn._tableFactory(r,o[e],t);n.forEach(function(n){n[e]||(i?Object.defineProperty(n,e,{configurable:!0,enumerable:!0,get:function(){var n=J.PSD&&J.PSD.trans;return n&&n.db===qn?n.tables[e]:u}}):n[e]=u)})})}function cn(n){n.forEach(function(n){for(var t in n)n[t]instanceof Z&&delete n[t]})}function an(n,t,e,r,o,i){var c=J.PSD;i=i||u,n.onerror||(n.onerror=j(o)),t?n.onsuccess=g(function(u){var c=n.result;if(c){var a=function(){c["continue"]()};t(c,function(n){a=n},r,o)&&e(i(c.value),c,function(n){a=n}),a()}else r()},o,c):n.onsuccess=g(function(t){var o=n.result;if(o){var u=function(){o["continue"]()};e(i(o.value),o,function(n){u=n}),u()}else r()},o,c)}function sn(n){var t=[];return n.split(",").forEach(function(n){n=n.trim();var e=n.replace("&","").replace("++","").replace("*",""),r=0!==e.indexOf("[")?e:n.substring(n.indexOf("[")+1,n.indexOf("]")).split("+");t.push(new A(e,r||null,-1!==n.indexOf("&"),-1!==n.indexOf("*"),-1!==n.indexOf("++"),M(r),-1!==r.indexOf(".")))}),t}function fn(n,t){return Pn.cmp(n,t)}function hn(n,t){return fn(n,t)<0?n:t}function ln(n,t){return fn(n,t)>0?n:t}function dn(n,t){return Pn.cmp(n,t)}function pn(n,t){return Pn.cmp(t,n)}function vn(n,t){return t>n?-1:n===t?0:1}function yn(n,t){return n>t?-1:n===t?0:1}function mn(n,t){return n?t?function(){return n.apply(this,arguments)&&t.apply(this,arguments)}:n:t}function bn(){return navigator.userAgent.indexOf("Trident")>=0||navigator.userAgent.indexOf("MSIE")>=0}function gn(){if(qn.verno=Kn.version/10,qn._dbSchema=On={},jn=e(Kn.objectStoreNames,0),0!==jn.length){var n=Kn.transaction(F(jn),"readonly");jn.forEach(function(t){for(var e=n.objectStore(t),r=e.keyPath,o=r&&"string"==typeof r&&-1!==r.indexOf("."),i=new A(r,r||"",!1,!1,!!e.autoIncrement,r&&"string"!=typeof r,o),u=[],c=0;c<e.indexNames.length;++c){var a=e.index(e.indexNames[c]);r=a.keyPath,o=r&&"string"==typeof r&&-1!==r.indexOf(".");var s=new A(a.name,r,!!a.unique,!!a.multiEntry,!1,r&&"string"!=typeof r,o);u.push(s)}On[t]=new B(t,i,u,{})}),un([Cn],qn._transPromiseFactory,R(On),Fn,On)}}function wn(n,t){for(var r=t.db.objectStoreNames,o=0;o<r.length;++o)for(var i=r[o],u=t.objectStore(i),c=0;c<u.indexNames.length;++c){var a=u.indexNames[c],s=u.index(a).keyPath,f="string"==typeof s?s:"["+e(s).join("+")+"]";if(n[i]){var h=n[i].idxByName[f];h&&(h.name=a)}}}var _n=h&&h.addons||o.addons,xn=o.dependencies,Pn=xn.indexedDB,Sn=xn.IDBKeyRange,Dn=xn.TypeError,kn=xn.Error,On=this._dbSchema={},En=[],jn=[],Cn={},Tn={},Kn=null,In=!0,An=null,Bn=!1,Nn="readonly",Fn="readwrite",qn=this,Rn=[],Mn=!0,Un=!!q();this.version=function(n){if(Kn)throw new kn("Cannot add version when database is open");this.verno=Math.max(this.verno,n);var t=En.filter(function(t){return t._cfg.version===n})[0];return t?t:(t=new b(n),En.push(t),En.sort(on),t)},n(b.prototype,{stores:function(t){this._cfg.storesSource=this._cfg.storesSource?n(this._cfg.storesSource,t):t;var e={};En.forEach(function(t){n(e,t._cfg.storesSource)});var r=this._cfg.dbschema={};return this._parseStoresSpec(e,r),On=qn._dbSchema=r,cn([Cn,qn,Tn]),un([Tn],X,R(r),Fn,r),un([Cn,qn,this._cfg.tables],qn._transPromiseFactory,R(r),Fn,r,!0),jn=R(r),this},upgrade:function(n){var t=this;return H(function(){n(qn._createTransaction(Fn,R(t._cfg.dbschema),t._cfg.dbschema))}),this._cfg.contentUpgrade=n,this},_parseStoresSpec:function(n,t){R(n).forEach(function(e){if(null!==n[e]){var r={},o=sn(n[e]),i=o.shift();if(i.multi)throw new kn("Primary key cannot be multi-valued");i.keyPath&&x(r,i.keyPath,i.auto?0:i.keyPath),o.forEach(function(n){if(n.auto)throw new kn("Only primary key can be marked as autoIncrement (++)");if(!n.keyPath)throw new kn("Index must have a name and cannot be an empty string");x(r,n.keyPath,n.compound?n.keyPath.map(function(){return""}):"")}),t[e]=new B(e,i,o,r)}})}}),this._allTables=Cn,this._tableFactory=function(n,t,e){return n===Nn?new Z(t.name,e,t,en):new $(t.name,e,t)},this._createTransaction=function(n,t,e,r){return new nn(n,t,e,r)},this._transPromiseFactory=function(n,t,e){if(!In||J.PSD&&J.PSD.letThrough){var r=qn._createTransaction(n,t,On);return r._promise(n,function(n,t){r.error(function(n){qn.on("error").fire(n)}),J.newPSD(function(){J.PSD.trans=r,e(function(t){r.complete(function(){n(t)})},t,r)})})}Bn||qn.open();var o=new J(function(r,i){Rn.push({resume:function(){var u=qn._transPromiseFactory(n,t,e);o.onuncatched=u.onuncatched,u.then(r,i)}})});return o},this._whenReady=function(n){return Y||!In||J.PSD&&J.PSD.letThrough?new J(n):(Bn||qn.open(),new J(function(t,e){Rn.push({resume:function(){n(t,e)}})}))},this.verno=0,this.open=function(){return new J(function(n,t){function e(n){try{r.transaction.abort()}catch(e){}if(Kn)try{Kn.close()}catch(e){}Kn=null,Bn=!1,An=n,In=!1,t(An),Rn.forEach(function(n){n.resume()}),Rn=[]}if(Y&&n(qn),Kn)return void n(qn);if(Bn)return void qn._whenReady(function(){n(qn)},function(n){t(n)});var r,o=!1;try{if(An=null,Bn=!0,En.length>0&&(Mn=!1),!Pn)throw new kn("indexedDB API not found. If using IE10+, make sure to run your code on a server URL (not locally). If using Safari, make sure to include indexedDB polyfill.");if(r=Mn?Pn.open(a):Pn.open(a,Math.round(10*qn.verno)),!r)throw new kn("IndexedDB API not available");r.onerror=j(e,["opening database",a]),r.onblocked=function(n){qn.on("blocked").fire(n)},r.onupgradeneeded=g(function(n){if(Mn&&!qn._allowEmptyDB){r.onerror=function(n){n.preventDefault()},r.transaction.abort(),r.result.close();var t=Pn.deleteDatabase(a);t.onsuccess=t.onerror=function(){e(new kn("Database '"+a+"' doesnt exist"))}}else{0===n.oldVersion&&(o=!0),r.transaction.onerror=j(e);var i=n.oldVersion>Math.pow(2,62)?0:n.oldVersion;P(i/10,r.transaction,e,r)}},e),r.onsuccess=g(function(t){if(Bn=!1,Kn=r.result,Mn)gn();else if(Kn.objectStoreNames.length>0)try{wn(On,Kn.transaction(F(Kn.objectStoreNames),Nn))}catch(t){}Kn.onversionchange=qn.on("versionchange").fire,Un||K(function(n){return-1===n.indexOf(a)?n.push(a):void 0}),J.newPSD(function(){function t(){In=!1,Rn.forEach(function(n){n.resume()}),Rn=[],n(qn)}J.PSD.letThrough=!0;try{var r=qn.on.ready.fire();r&&"function"==typeof r.then?r.then(t,function(n){Kn.close(),Kn=null,e(n)}):m(t)}catch(o){e(o)}})},e)}catch(i){e(i)}})},this.close=function(){Kn&&(Kn.close(),Kn=null,In=!0,An=null)},this["delete"]=function(){var n=arguments;return new J(function(t,e){function r(){qn.close();var n=Pn.deleteDatabase(a);n.onsuccess=function(){Un||K(function(n){var t=n.indexOf(a);return t>=0?n.splice(t,1):void 0}),t()},n.onerror=j(e,["deleting",a]),n.onblocked=function(){qn.on("blocked").fire()}}if(n.length>0)throw new kn("Arguments not allowed in db.delete()");Bn?Rn.push({resume:r}):r()})},this.backendDB=function(){return Kn},this.isOpen=function(){return null!==Kn},this.hasFailed=function(){return null!==An},this.dynamicallyOpened=function(){return Mn},this.name=a,Object.defineProperty(this,"tables",{get:function(){return R(Cn).map(function(n){return Cn[n]})}}),this.on=v(this,"error","populate","blocked",{ready:[p,i],versionchange:[l,i]}),this.on.ready.subscribe=r(this.on.ready.subscribe,function(n){return function(t,e){function r(){return e||qn.on.ready.unsubscribe(r),t.apply(this,arguments)}n.call(this,r),qn.isOpen()&&(In?Rn.push({resume:r}):r())}}),H(function(){qn.on("populate").fire(qn._createTransaction(Fn,jn,On)),qn.on("error").fire(new kn)}),this.transaction=function(n,t,o){function i(t,e){var i=null;try{if(s)throw s;i=qn._createTransaction(n,f,On,u);var c=f.map(function(n){return i.tables[n]});c.push(i);var a,h=0;J.newPSD(function(){J.PSD.trans=i,i.scopeFunc=o,u&&(i.idbtrans=u.idbtrans,i._promise=r(i._promise,function(n){return function(t,e,r){function o(n){return function(t){var e;return J._rootExec(function(){e=n(t),J._tickFinalize(function(){0===--h&&i.active&&(i.active=!1,i.on.complete.fire())})}),e}}return++h,n.call(this,t,function(n,t,r){return e(o(n),o(t),r)},r)}})),i.complete(function(){t(a)}),i.error(function(n){i.idbtrans&&(i.idbtrans.onerror=T);try{i.abort()}catch(t){}u&&(u.active=!1,u.on.error.fire(n));var r=e(n);u||r||qn.on.error.fire(n)}),J._rootExec(function(){a=o.apply(i,c),a&&"function"==typeof a.next&&"function"==typeof a["throw"]&&(a=I(a))})}),(!i.idbtrans||u&&0===h)&&i._nop()}catch(l){i&&i.idbtrans&&(i.idbtrans.onerror=T),i&&i.abort(),u&&u.on.error.fire(l),m(function(){e(l)||qn.on("error").fire(l)})}}t=e(arguments,1,arguments.length-1),o=arguments[arguments.length-1];var u=J.PSD&&J.PSD.trans;u&&u.db===qn&&-1===n.indexOf("!")||(u=null);var c=-1!==n.indexOf("?");n=n.replace("!","").replace("?","");var a=M(t[0])?t.reduce(function(n,t){return n.concat(t)}):t,s=null,f=a.map(function(n){return"string"==typeof n?n:(n instanceof Z||(s=s||new Dn("Invalid type. Arguments following mode must be instances of Table or String")),n.name)});return"r"==n||n==Nn?n=Nn:"rw"==n||n==Fn?n=Fn:s=new kn("Invalid transaction mode: "+n),u&&(s||(u&&u.mode===Nn&&n===Fn&&(c?u=null:s=s||new kn("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY")),u&&f.forEach(function(n){u.tables.hasOwnProperty(n)||(c?u=null:s=s||new kn("Table "+n+" not included in parent transaction. Parent Transaction function: "+u.scopeFunc.toString()))}))),u?u._promise(n,i,"lock"):qn._whenReady(i)},this.table=function(n){if(Y&&Mn)return new $(n);if(!Cn.hasOwnProperty(n))throw new kn("Table does not exist");return Cn[n]},n(Z.prototype,function(){function n(){throw new kn("Current Transaction is READONLY")}return{_trans:function(n,t,e){return this._tpf(n,[this.name],t,e)},_idbstore:function(n,t,e){if(Y)return new J(t);var r=this;return this._tpf(n,[this.name],function(n,e,o){t(n,e,o.idbtrans.objectStore(r.name),o)},e)},get:function(n,t){var e=this;return this._idbstore(Nn,function(t,r,o){Y&&t(e.schema.instanceTemplate);var i=o.get(n);i.onerror=j(r,["getting",n,"from",e.name]),i.onsuccess=function(){t(e.hook.reading.fire(i.result))}}).then(t)},where:function(n){return new tn(this,n)},count:function(n){return this.toCollection().count(n)},offset:function(n){return this.toCollection().offset(n)},limit:function(n){return this.toCollection().limit(n)},reverse:function(){return this.toCollection().reverse()},filter:function(n){return this.toCollection().and(n)},each:function(n){var t=this;return Y&&n(t.schema.instanceTemplate),this._idbstore(Nn,function(e,r,o){var i=o.openCursor();i.onerror=j(r,["calling","Table.each()","on",t.name]),an(i,null,n,e,r,t.hook.reading.fire)})},toArray:function(n){var t=this;return this._idbstore(Nn,function(n,e,r){Y&&n([t.schema.instanceTemplate]);var o=[],i=r.openCursor();i.onerror=j(e,["calling","Table.toArray()","on",t.name]),an(i,null,function(n){o.push(n)},function(){n(o)},e,t.hook.reading.fire)}).then(n)},orderBy:function(n){return new this._collClass(new tn(this,n))},toCollection:function(){return new this._collClass(new tn(this))},mapToClass:function(n,t){this.schema.mappedClass=n;var e=Object.create(n.prototype);t&&E(e,t),this.schema.instanceTemplate=e;var r=function(t){if(!t)return t;var e=Object.create(n.prototype);for(var r in t)t.hasOwnProperty(r)&&(e[r]=t[r]);return e};return this.schema.readHook&&this.hook.reading.unsubscribe(this.schema.readHook),this.schema.readHook=r,this.hook("reading",r),n},defineClass:function(n){return this.mapToClass(o.defineClass(n),n)},add:n,put:n,"delete":n,clear:n,update:n}}),t($).from(Z).extend(function(){function n(n,t,e,r){return function(o){o.stopPropagation&&o.stopPropagation(),o.preventDefault&&o.preventDefault(),n.push(o.target.error),e&&e.onerror&&J.newPSD(function(){J.PSD.trans=r,e.onerror(o.target.error)}),t&&t(n)}}function t(n,t,e,r){return e?function(o){e.onsuccess&&J.newPSD(function(){J.PSD.trans=r,e.onsuccess(o.target.result)}),t&&t(n)}:function(){t(n)}}return{bulkAdd:function(e){var r=this.hook.creating.fire;return this._idbstore(Fn,function(o,u,c,a){if(!c.keyPath)throw new kn("bulkAdd() only support inbound keys");if(0===e.length)return o([]);var s,f,h,l=[];if(r!==i){var d=c.keyPath,p={onerror:null,onsuccess:null};f=n(l,null,p,a),h=t(l,null,p,a);for(var v=0,y=e.length;y>v;++v){var m=e[v],b=_(m,d),g=r.call(p,b,m,a);void 0===b&&void 0!==g&&(m=D(m),x(m,d,g)),s=c.add(m),y-1>v&&(s.onerror=f,p.onsuccess&&(s.onsuccess=h),p.onerror=null,p.onsuccess=null)}s.onerror=n(l,o,p,a),s.onsuccess=t(l,o,p,a)}else{f=n(l);for(var v=0,y=e.length;y>v;++v)s=c.add(e[v]),s.onerror=f;s.onerror=n(l,o),s.onsuccess=t(l,o)}})},add:function(n,t){var e=this,r=this.hook.creating.fire;return this._idbstore(Fn,function(o,u,c,a){var s={onsuccess:null,onerror:null};if(r!==i){var f=t||(c.keyPath?_(n,c.keyPath):void 0),h=r.call(s,f,n,a);void 0===f&&void 0!==h&&(c.keyPath?x(n,c.keyPath,h):t=h)}var l=void 0!==t?c.add(n,t):c.add(n);l.onerror=j(function(n){return s.onerror&&J.newPSD(function(){J.PSD.trans=a,s.onerror(n)}),u(n)},["adding",n,"into",e.name]),l.onsuccess=function(t){var e=c.keyPath;e&&x(n,e,t.target.result),s.onsuccess&&J.newPSD(function(){J.PSD.trans=a,s.onsuccess(t.target.result)}),o(l.result)}})},put:function(n,t){var e=this,r=this.hook.creating.fire,o=this.hook.updating.fire;return r!==i||o!==i?this._trans(Fn,function(r,o,i){var u=t||e.schema.primKey.keyPath&&_(n,e.schema.primKey.keyPath);void 0===u?i.tables[e.name].add(n).then(r,o):(i._lock(),n=D(n),i.tables[e.name].where(":id").equals(u).modify(function(t){this.value=n}).then(function(r){return 0===r?i.tables[e.name].add(n,t):u})["finally"](function(){i._unlock()}).then(r,o))}):this._idbstore(Fn,function(r,o,i){var u=void 0!==t?i.put(n,t):i.put(n);u.onerror=j(o,["putting",n,"into",e.name]),u.onsuccess=function(t){var e=i.keyPath;e&&x(n,e,t.target.result),r(u.result)}})},"delete":function(n){return this.hook.deleting.subscribers.length?this.where(":id").equals(n)["delete"]():this._idbstore(Fn,function(t,e,r){var o=r["delete"](n);o.onerror=j(e,["deleting",n,"from",r.name]),o.onsuccess=function(n){t(o.result)}})},clear:function(){return this.hook.deleting.subscribers.length?this.toCollection()["delete"]():this._idbstore(Fn,function(n,t,e){var r=e.clear();r.onerror=j(t,["clearing",e.name]),r.onsuccess=function(t){n(r.result)}})},update:function(n,t){if("object"!=typeof t||M(t))throw new kn("db.update(keyOrObject, modifications). modifications must be an object.");if("object"!=typeof n||M(n))return this.where(":id").equals(n).modify(t);R(t).forEach(function(e){x(n,e,t[e])});var e=_(n,this.schema.primKey.keyPath);return void 0===e&&J.reject(new kn("Object does not contain its primary key")),this.where(":id").equals(e).modify(t)}}}),n(nn.prototype,{_lock:function(){return++this._reculock,1===this._reculock&&J.PSD&&(J.PSD.lockOwnerFor=this),this},_unlock:function(){if(0===--this._reculock)for(J.PSD&&(J.PSD.lockOwnerFor=null);this._blockedFuncs.length>0&&!this._locked();){var n=this._blockedFuncs.shift();try{n()}catch(t){}}return this},_locked:function(){return this._reculock&&(!J.PSD||J.PSD.lockOwnerFor!==this)},_nop:function(n){this.tables[this.storeNames[0]].get(0).then(n)},_promise:function(n,t,e){var r=this;return J.newPSD(function(){var i;return r._locked()?i=new J(function(o,i){r._blockedFuncs.push(function(){r._promise(n,t,e).then(o,i)})}):(i=r.active?new J(function(i,u){if(!r.idbtrans&&n){if(!Kn)throw new kn(An?"Database not open. Following error in populate, ready or upgrade function made Dexie.open() fail: "+An:"Database not open");var c=r.idbtrans=Kn.transaction(F(r.storeNames),r.mode);c.onerror=function(n){r.on("error").fire(n&&n.target.error),n.preventDefault(),r.abort()},c.onabort=function(n){m(function(){r.on("error").fire(new kn("Transaction aborted for unknown reason"))}),r.active=!1,r.on("abort").fire(n)},c.oncomplete=function(n){r.active=!1,r.on("complete").fire(n)}}e&&r._lock();try{t(i,u,r)}catch(a){o.ignoreTransaction(function(){r.on("error").fire(a)}),r.abort();try{throw new kn(a)}catch(s){u(s)}}}):J.reject(C(new kn("Transaction is inactive. Original Scope Function Source: "+r.scopeFunc.toString()))),r.active&&e&&i["finally"](function(){r._unlock()})),i.onuncatched=function(n){o.ignoreTransaction(function(){r.on("error").fire(n)}),r.abort()},i})},complete:function(n){return this.on("complete",n)},error:function(n){return this.on("error",n)},abort:function(){if(this.idbtrans&&this.active)try{this.active=!1,this.idbtrans.abort(),this.on.error.fire(new kn("Transaction Aborted"))}catch(n){}},table:function(n){if(!this.tables.hasOwnProperty(n))throw new kn("Table "+n+" not in transaction");return this.tables[n]}}),n(tn.prototype,function(){function n(n,t,e){var r=n instanceof tn?new n._ctx.collClass(n):n;try{throw e?new e(t):new Dn(t)}catch(o){r._ctx.error=o}return r}function t(n){return new n._ctx.collClass(n,function(){return Sn.only("")}).limit(0)}function r(n){return e(1===n.length&&M(n[0])?n[0]:n)}function o(n){return"next"===n?function(n){return n.toUpperCase()}:function(n){return n.toLowerCase()}}function i(n){return"next"===n?function(n){return n.toLowerCase()}:function(n){return n.toUpperCase()}}function u(n,t,e,r,o,i){for(var u=Math.min(n.length,r.length),c=-1,a=0;u>a;++a){var s=t[a];if(s!==r[a])return o(n[a],e[a])<0?n.substr(0,a)+e[a]+e.substr(a+1):o(n[a],r[a])<0?n.substr(0,a)+r[a]+e.substr(a+1):c>=0?n.substr(0,c)+t[c]+e.substr(c+1):null;o(n[a],s)<0&&(c=a)}return u<r.length&&"next"===i?n+e.substr(n.length):u<n.length&&"prev"===i?n.substr(0,e.length):0>c?null:n.substr(0,c)+r[c]+e.substr(c+1)}function c(n,t,e,r){function c(n){a=o(n),s=i(n),f="next"===n?vn:yn;var t=e.map(function(n){return{lower:s(n),upper:a(n)}}).sort(function(n,t){return f(n.lower,t.lower)});h=t.map(function(n){return n.upper}),l=t.map(function(n){return n.lower}),d=n,p="next"===n?"":r}var a,s,f,h,l,d,p,v=e.length;c("next");var y=new n._ctx.collClass(n,function(){return Sn.bound(h[0],l[v-1]+r)});y._ondirectionchange=function(n){c(n)};var m=0;return y._addAlgorithm(function(n,e,r){var o=n.key;if("string"!=typeof o)return!1;var i=s(o);if(t(i,l,m))return!0;for(var c=null,a=m;v>a;++a){var y=u(o,i,h[a],l[a],f,d);null===y&&null===c?m=a+1:(null===c||f(c,y)>0)&&(c=y)}return e(null!==c?function(){n["continue"](c+p)}:r),!1}),y}return{between:function(e,r,o,i){o=o!==!1,i=i===!0;try{return fn(e,r)>0||0===fn(e,r)&&(o||i)&&(!o||!i)?t(this):new this._ctx.collClass(this,function(){return Sn.bound(e,r,!o,!i)})}catch(u){return n(this,z)}},equals:function(n){return new this._ctx.collClass(this,function(){return Sn.only(n)})},above:function(n){return new this._ctx.collClass(this,function(){return Sn.lowerBound(n,!0)})},aboveOrEqual:function(n){return new this._ctx.collClass(this,function(){return Sn.lowerBound(n)})},below:function(n){return new this._ctx.collClass(this,function(){return Sn.upperBound(n,!0)})},belowOrEqual:function(n){return new this._ctx.collClass(this,function(){return Sn.upperBound(n)})},startsWith:function(t){return"string"!=typeof t?n(this,"String expected"):this.between(t,t+L,!0,!0)},startsWithIgnoreCase:function(t){return"string"!=typeof t?n(this,"String expected"):""===t?this.startsWith(t):c(this,function(n,t){return 0===n.indexOf(t[0])},[t],L)},equalsIgnoreCase:function(t){return"string"!=typeof t?n(this,"String expected"):c(this,function(n,t){return n===t[0]},[t],"")},anyOfIgnoreCase:function(e){var o=r(arguments);return 0===o.length?t(this):o.every(function(n){return"string"==typeof n})?c(this,function(n,t){return-1!==t.indexOf(n)},o,""):n(this,"anyOfIgnoreCase() only works with strings")},startsWithAnyOfIgnoreCase:function(e){var o=r(arguments);return 0===o.length?t(this):o.every(function(n){return"string"==typeof n})?c(this,function(n,t){return t.some(function(t){return 0===n.indexOf(t)})},o,L):n(this,"anyOfIgnoreCase() only works with strings")},anyOf:function(e){var o=r(arguments),i=dn;try{o.sort(i)}catch(u){return n(this,z)}if(0===o.length)return t(this);var c=new this._ctx.collClass(this,function(){return Sn.bound(o[0],o[o.length-1])});c._ondirectionchange=function(n){i="next"===n?dn:pn,o.sort(i)};var a=0;return c._addAlgorithm(function(n,t,e){for(var r=n.key;i(r,o[a])>0;)if(++a,a===o.length)return t(e),!1;return 0===i(r,o[a])?!0:(t(function(){n["continue"](o[a])}),!1)}),c},notEqual:function(n){return this.inAnyRange([[-(1/0),n],[n,V]],{includeLowers:!1,includeUppers:!1})},noneOf:function(t){var e=r(arguments);if(0===e.length)return new this._ctx.collClass(this);try{e.sort(dn)}catch(o){return n(this,z)}var i=e.reduce(function(n,t){return n?n.concat([[n[n.length-1][1],t]]):[[-(1/0),t]]},null);return i.push([e[e.length-1],V]),this.inAnyRange(i,{includeLowers:!1,includeUppers:!1})},inAnyRange:function(e,r){function o(n,t){for(var e=0,r=n.length;r>e;++e){var o=n[e];if(fn(t[0],o[1])<0&&fn(t[1],o[0])>0){o[0]=hn(o[0],t[0]),o[1]=ln(o[1],t[1]);break}}return e===r&&n.push(t),n}function i(n,t){return h(n[0],t[0])}function u(n){return!p(n)&&!v(n)}var c=this._ctx;if(0===e.length)return t(this);if(!e.every(function(n){return void 0!==n[0]&&void 0!==n[1]&&dn(n[0],n[1])<=0}))return n(this,"First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower",kn);var a,s=!r||r.includeLowers!==!1,f=r&&r.includeUppers===!0,h=dn;try{a=e.reduce(o,[]),a.sort(i)}catch(l){return n(this,z)}var d=0,p=f?function(n){return dn(n,a[d][1])>0}:function(n){return dn(n,a[d][1])>=0},v=s?function(n){return pn(n,a[d][0])>0}:function(n){return pn(n,a[d][0])>=0},y=p,m=new c.collClass(this,function(){return Sn.bound(a[0][0],a[a.length-1][1],!s,!f)});return m._ondirectionchange=function(n){"next"===n?(y=p,h=dn):(y=v,h=pn),a.sort(i)},m._addAlgorithm(function(n,t,e){for(var r=n.key;y(r);)if(++d,d===a.length)return t(e),!1;return u(r)?!0:0===fn(r,a[d][1])||0===fn(r,a[d][0])?!1:(t(function(){h===dn?n["continue"](a[d][0]):n["continue"](a[d][1])}),!1)}),m},startsWithAnyOf:function(e){var o=r(arguments);return o.every(function(n){return"string"==typeof n})?0===o.length?t(this):this.inAnyRange(o.map(function(n){return[n,n+L]})):n(this,"startsWithAnyOf() only works with strings")}}}),n(en.prototype,function(){function n(n,t){n.filter=mn(n.filter,t)}function t(n,t){n.isMatch=mn(n.isMatch,t)}function e(n,t){if(n.isPrimKey)return t;var e=n.table.schema.idxByName[n.index];if(!e)throw new kn("KeyPath "+n.index+" on object store "+t.name+" is not indexed");return n.isPrimKey?t:t.index(e.name)}function r(n,t){return e(n,t)[n.op](n.range||null,n.dir+n.unique)}function o(n,t,e,o,i){n.or?!function(){function u(){2===++f&&e()}function c(n,e,r){if(!a||a(e,r,u,o)){var i=e.primaryKey.toString();s.hasOwnProperty(i)||(s[i]=!0,t(n,e,r))}}var a=n.filter,s={},f=0;n.or._iterate(c,u,o,i),an(r(n,i),n.algorithm,c,u,o,n.table.hook.reading.fire)}():an(r(n,i),mn(n.algorithm,n.filter),t,e,o,n.table.hook.reading.fire)}function i(n){return n.table.schema.instanceTemplate}return{_read:function(n,t){var e=this._ctx;return e.error?e.table._trans(null,function(n,t){t(e.error)}):e.table._idbstore(Nn,n).then(t)},_write:function(n){var t=this._ctx;return t.error?t.table._trans(null,function(n,e){e(t.error)}):t.table._idbstore(Fn,n,"locked")},_addAlgorithm:function(n){var t=this._ctx;t.algorithm=mn(t.algorithm,n)},_iterate:function(n,t,e,r){return o(this._ctx,n,t,e,r)},each:function(n){var t=this._ctx;return Y&&n(i(t)),this._read(function(e,r,i){o(t,n,e,r,i)})},count:function(n){if(Y)return J.resolve(0).then(n);var t=this,r=this._ctx;if(r.filter||r.algorithm||r.or){var i=0;return this._read(function(n,t,e){o(r,function(){return++i,!1},function(){n(i)},t,e)},n)}return this._read(function(n,o,i){var u=e(r,i),c=r.range?u.count(r.range):u.count();c.onerror=j(o,["calling","count()","on",t.name]),c.onsuccess=function(t){n(Math.min(t.target.result,Math.max(0,r.limit-r.offset)))}},n)},sortBy:function(n,t){function e(n,t){return t?e(n[o[t]],t-1):n[i]}function r(n,t){var r=e(n,u),o=e(t,u);return o>r?-c:r>o?c:0}var o=n.split(".").reverse(),i=o[0],u=o.length-1,c="next"===this._ctx.dir?1:-1;return this.toArray(function(n){return n.sort(r)}).then(t)},toArray:function(n){var t=this._ctx;return this._read(function(n,e,r){Y&&n([i(t)]);var u=[];o(t,function(n){u.push(n)},function(){n(u)},e,r)},n)},offset:function(t){var e=this._ctx;return 0>=t?this:(e.offset+=t,e.or||e.algorithm||e.filter?n(e,function(n,e,r){return--t<0}):n(e,function(n,e,r){return 0===t?!0:1===t?(--t,!1):(e(function(){n.advance(t),t=0}),!1)}),this)},limit:function(t){return this._ctx.limit=Math.min(this._ctx.limit,t),n(this._ctx,function(n,e,r){return--t<=0&&e(r),t>=0}),this},until:function(t,e){var r=this._ctx;return Y&&t(i(r)),n(this._ctx,function(n,r,o){return t(n.value)?(r(o),e):!0}),this},first:function(n){return this.limit(1).toArray(function(n){return n[0]}).then(n)},last:function(n){return this.reverse().first(n)},and:function(e){return Y&&e(i(this._ctx)),n(this._ctx,function(n){return e(n.value)}),t(this._ctx,e),this},or:function(n){return new tn(this._ctx.table,n,this)},reverse:function(){return this._ctx.dir="prev"===this._ctx.dir?"next":"prev",this._ondirectionchange&&this._ondirectionchange(this._ctx.dir),this},desc:function(){return this.reverse()},eachKey:function(n){var t=this._ctx;return Y&&n(_(i(this._ctx),this._ctx.index?this._ctx.table.schema.idxByName[this._ctx.index].keyPath:this._ctx.table.schema.primKey.keyPath)),t.isPrimKey||(t.op="openKeyCursor"),this.each(function(t,e){n(e.key,e)})},eachUniqueKey:function(n){return this._ctx.unique="unique",this.eachKey(n)},keys:function(n){var t=this._ctx;t.isPrimKey||(t.op="openKeyCursor");var e=[];return Y?new J(this.eachKey.bind(this)).then(function(n){return[n]}).then(n):this.each(function(n,t){e.push(t.key)}).then(function(){return e}).then(n)},uniqueKeys:function(n){return this._ctx.unique="unique",this.keys(n)},firstKey:function(n){return this.limit(1).keys(function(n){return n[0]}).then(n)},lastKey:function(n){return this.reverse().firstKey(n)},distinct:function(){var t={};return n(this._ctx,function(n){var e=n.primaryKey.toString(),r=t.hasOwnProperty(e);return t[e]=!0,!r}),this}}}),t(rn).from(en).extend({modify:function(t){var e=this,r=this._ctx,o=r.table.hook,u=o.updating.fire,c=o.deleting.fire;return Y&&"function"==typeof t&&t.call({value:r.table.schema.instanceTemplate},r.table.schema.instanceTemplate),this._write(function(o,a,s,f){function h(n,t,e){function o(n){return O.push(n),E.push(i.primKey),i.onerror&&J.newPSD(function(){J.PSD.trans=f,i.onerror(n)}),d(),!0}C=t.primaryKey;var i={primKey:t.primaryKey,value:n,onsuccess:null,onerror:null};if(p.call(i,n)!==!1){var u=!i.hasOwnProperty("value");++b,w(function(){var e=u?t["delete"]():t.update(i.value);e.onerror=j(o,u?["deleting",n,"from",r.table.name]:["modifying",n,"on",r.table.name]),e.onsuccess=function(n){i.onsuccess&&J.newPSD(function(){J.PSD.trans=f,i.onsuccess(i.value)}),++g,d()}},o)}else i.onsuccess&&i.onsuccess(i.value)}function l(n){return n&&(O.push(n),E.push(C)),a(new N("Error modifying one or more objects",O,g,E))}function d(){P&&g+O.length===b&&(O.length>0?l():o(g))}var p;if("function"==typeof t)p=u===i&&c===i?t:function(n){var e=D(n);if(t.call(this,n)===!1)return!1;
if(this.hasOwnProperty("value")){var r=k(e,this.value),o=u.call(this,r,this.primKey,e,f);o&&(n=this.value,R(o).forEach(function(t){x(n,t,o[t])}))}else c.call(this,this.primKey,n,f)};else if(u===i){var v=R(t),y=v.length;p=function(n){for(var e=!1,r=0;y>r;++r){var o=v[r],i=t[o];_(n,o)!==i&&(x(n,o,i),e=!0)}return e}}else{var m=t;t=S(m),p=function(e){var r=!1,o=u.call(this,t,this.primKey,D(e),f);return o&&n(t,o),R(t).forEach(function(n){var o=t[n];_(e,n)!==o&&(x(e,n,o),r=!0)}),o&&(t=S(m)),r}}var b=0,g=0,P=!1,O=[],E=[],C=null;e._iterate(h,function(){P=!0,d()},l,s)})},"delete":function(){return this.modify(function(){delete this.value})}}),n(this,{Collection:en,Table:Z,Transaction:nn,Version:b,WhereClause:tn,WriteableCollection:rn,WriteableTable:$}),y(),_n.forEach(function(n){n(qn)})}function i(){}function u(n){return n}function c(n,t){return n===u?t:function(e){return t(n(e))}}function a(n,t){return function(){n.apply(this,arguments),t.apply(this,arguments)}}function s(n,t){return n===i?t:function(){var e=n.apply(this,arguments);void 0!==e&&(arguments[0]=e);var r=this.onsuccess,o=this.onerror;this.onsuccess=null,this.onerror=null;var i=t.apply(this,arguments);return r&&(this.onsuccess=this.onsuccess?a(r,this.onsuccess):r),o&&(this.onerror=this.onerror?a(o,this.onerror):o),void 0!==i?i:e}}function f(t,e){return t===i?e:function(){var r=t.apply(this,arguments);void 0!==r&&n(arguments[0],r);var o=this.onsuccess,i=this.onerror;this.onsuccess=null,this.onerror=null;var u=e.apply(this,arguments);return o&&(this.onsuccess=this.onsuccess?a(o,this.onsuccess):o),i&&(this.onerror=this.onerror?a(i,this.onerror):i),void 0===r?void 0===u?void 0:u:void 0===u?r:n(r,u)}}function h(n,t){return n===i?t:function(){return n.apply(this,arguments)===!1?!1:t.apply(this,arguments)}}function l(n,t){return n===i?t:function(){return t.apply(this,arguments)===!1?!1:n.apply(this,arguments)}}function d(n,t){return n===i?t:function(){n.apply(this,arguments),t.apply(this,arguments)}}function p(n,t){return n===i?t:function(){var e=n.apply(this,arguments);if(e&&"function"==typeof e.then){var r=this,o=arguments;return e.then(function(){return t.apply(r,o)})}return t.apply(this,arguments)}}function v(n,t){function r(n,t,e){if(M(n))return u(n);if("object"==typeof n)return o(n);t||(t=h),e||(e=i);var r={subscribers:[],fire:e,subscribe:function(n){r.subscribers.push(n),r.fire=t(r.fire,n)},unsubscribe:function(n){r.subscribers=r.subscribers.filter(function(t){return t!==n}),r.fire=r.subscribers.reduce(t,e)}};return a[n]=s[n]=r,r}function o(n){R(n).forEach(function(t){var e=n[t];if(M(e))r(t,n[t][0],n[t][1]);else{if("asap"!==e)throw new Error("Invalid event config");var o=r(t,null,function(){var n=arguments;o.subscribers.forEach(function(t){m(function(){t.apply(W,n)})})});o.subscribe=function(n){-1===o.subscribers.indexOf(n)&&o.subscribers.push(n)},o.unsubscribe=function(n){var t=o.subscribers.indexOf(n);-1!==t&&o.subscribers.splice(t,1)}}})}function u(n){function t(){return e?!1:void(e=!0)}var e=!1;n.forEach(function(n){r(n).subscribe(t)})}var c=arguments,a={},s=function(t,r){if(r){var o=e(arguments,1),i=a[t];return i.subscribe.apply(i,o),n}return"string"==typeof t?a[t]:void 0};s.addEventType=r;for(var f=1,l=c.length;l>f;++f)r(c[f]);return s}function y(n){if(!n)throw new Error("Assertion failed")}function m(n){W.setImmediate?setImmediate(n):setTimeout(n,0)}function b(n){var t=setTimeout(n,1e3);clearTimeout(t)}function g(n,t,e){return function(){var r=J.PSD;J.PSD=e;try{n.apply(this,arguments)}catch(o){t(o)}finally{J.PSD=r}}}function w(n,t){try{n()}catch(e){t(e)}}function _(n,t){if(n.hasOwnProperty(t))return n[t];if(!t)return n;if("string"!=typeof t){for(var e=[],r=0,o=t.length;o>r;++r){var i=_(n,t[r]);e.push(i)}return e}var u=t.indexOf(".");if(-1!==u){var c=n[t.substr(0,u)];return void 0===c?void 0:_(c,t.substr(u+1))}}function x(n,t,e){if(n&&void 0!==t&&!("isFrozen"in Object&&Object.isFrozen(n)))if("string"!=typeof t&&"length"in t){y("string"!=typeof e&&"length"in e);for(var r=0,o=t.length;o>r;++r)x(n,t[r],e[r])}else{var i=t.indexOf(".");if(-1!==i){var u=t.substr(0,i),c=t.substr(i+1);if(""===c)void 0===e?delete n[u]:n[u]=e;else{var a=n[u];a||(a=n[u]={}),x(a,c,e)}}else void 0===e?delete n[t]:n[t]=e}}function P(n,t){"string"==typeof t?x(n,t,void 0):"length"in t&&[].map.call(t,function(t){x(n,t,void 0)})}function S(n){var t={};for(var e in n)n.hasOwnProperty(e)&&(t[e]=n[e]);return t}function D(n){if(!n||"object"!=typeof n)return n;var t;if(M(n)){t=[];for(var e=0,r=n.length;r>e;++e)t.push(D(n[e]))}else if(n instanceof Date)t=new Date,t.setTime(n.getTime());else{t=n.constructor?Object.create(n.constructor.prototype):{};for(var o in n)n.hasOwnProperty(o)&&(t[o]=D(n[o]))}return t}function k(n,t){var e={};for(var r in n)n.hasOwnProperty(r)&&(t.hasOwnProperty(r)?n[r]!==t[r]&&JSON.stringify(n[r])!=JSON.stringify(t[r])&&(e[r]=t[r]):e[r]=void 0);for(var r in t)t.hasOwnProperty(r)&&!n.hasOwnProperty(r)&&(e[r]=t[r]);return e}function O(n){if("function"==typeof n)return new n;if(M(n))return[O(n[0])];if(n&&"object"==typeof n){var t={};return E(t,n),t}return n}function E(n,t){return R(t).forEach(function(e){var r=O(t[e]);n[e]=r}),n}function j(n,t){return function(e){var r=e&&e.target.error||new Error;if(t){var o=" occurred when "+t.map(function(n){switch(typeof n){case"function":return n();case"string":return n;default:return JSON.stringify(n)}}).join(" ");r.name?r.toString=function(){return r.name+o+(r.message?". "+r.message:"")}:r+=o}return n(r),e&&(e.stopPropagation&&e.stopPropagation(),e.preventDefault&&e.preventDefault()),!1}}function C(n){try{throw n}catch(t){return t}}function T(n){n.preventDefault()}function K(n){var t,e=o.dependencies.localStorage;if(!e)return n([]);try{t=JSON.parse(e.getItem("Dexie.DatabaseNames")||"[]")}catch(r){t=[]}n(t)&&e.setItem("Dexie.DatabaseNames",JSON.stringify(t))}function I(n){function t(n){return function(t){var r=n(t),o=r.value;return r.done?o:o&&"function"==typeof o.then?o.then(i,u):Array.isArray(o)?e(o,0):i(o)}}function e(n,t){if(t===n.length)return i(n);var r=n[t];return r.constructor&&"function"==typeof r.constructor.all?r.constructor.all(n).then(i,u):e(n,t+1)}var r=function(t){return n.next(t)},o=function(t){return n["throw"](t)},i=t(r),u=t(o);return t(r)()}function A(n,t,e,r,o,i,u){this.name=n,this.keyPath=t,this.unique=e,this.multi=r,this.auto=o,this.compound=i,this.dotted=u;var c="string"==typeof t?t:t&&"["+[].join.call(t,"+")+"]";this.src=(e?"&":"")+(r?"*":"")+(o?"++":"")+c}function B(n,t,e,r){this.name=n,this.primKey=t||new A,this.indexes=e||[new A],this.instanceTemplate=r,this.mappedClass=null,this.idxByName=e.reduce(function(n,t){return n[t.name]=t,n},{})}function N(n,t,e,r){this.name="ModifyError",this.failures=t,this.failedKeys=r,this.successCount=e,this.message=t.join("\n")}function F(n){return 1===n.length?n[0]:n}function q(){var n=o.dependencies.indexedDB,t=n&&(n.getDatabaseNames||n.webkitGetDatabaseNames);return t&&t.bind(n)}var R=Object.keys,M=Array.isArray,U=[].slice;if("undefined"==typeof W)var W=self||window;var L=String.fromCharCode(65535),V=function(){try{return IDBKeyRange.only([[]]),[[]]}catch(n){return L}}(),z="Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.",J=function(){function n(n,t){m.push([n,e(arguments,1)])}function t(){var n=m;m=[];for(var t=0,e=n.length;e>t;++t){var r=n[t];r[0].apply(W,r[1])}}function r(n){if("object"!=typeof this)throw new TypeError("Promises must be constructed via new");if("function"!=typeof n)throw new TypeError("not a function");this._state=null,this._value=null,this._deferreds=[],this._catched=!1;var t=this,e=!0;this._PSD=r.PSD;try{l(this,n,function(n){e?p(a,t,n):a(t,n)},function(n){return e?(p(s,t,n),!1):s(t,n)})}finally{e=!1}}function o(e,o){if(null===e._state)return void e._deferreds.push(o);var i=e._state?o.onFulfilled:o.onRejected;if(null===i)return(e._state?o.resolve:o.reject)(e._value);var u,a=y;y=!1,p=n;try{var s=r.PSD;r.PSD=e._PSD,u=i(e._value),e._state||u&&"function"==typeof u.then&&u._state===!1||c(e),o.resolve(u)}catch(f){var h=o.reject(f);if(!h&&e.onuncatched)try{e.onuncatched(f)}catch(f){}}finally{if(r.PSD=s,a){do{for(;m.length>0;)t();var l=g.pop();if(l)try{l()}catch(f){}}while(g.length>0||m.length>0);p=d,y=!0}}}function u(e){var r=y;y=!1,p=n;try{e()}finally{if(r){do{for(;m.length>0;)t();var o=g.pop();if(o)try{o()}catch(i){}}while(g.length>0||m.length>0);p=d,y=!0}}}function c(n){n._catched=!0,n._parent&&c(n._parent)}function a(n,t){var e=r.PSD;r.PSD=n._PSD;try{if(t===n)throw new TypeError("A promise cannot be resolved with itself.");if(t&&("object"==typeof t||"function"==typeof t)&&"function"==typeof t.then)return void l(n,function(n,e){t.then(n,e)},function(t){a(n,t)},function(t){s(n,t)});n._state=!0,n._value=t,f.call(n)}catch(o){s(o)}finally{r.PSD=e}}function s(n,t){var e=r.PSD;if(r.PSD=n._PSD,n._state=!1,n._value=t,f.call(n),!n._catched)try{n.onuncatched&&n.onuncatched(n._value),r.on.error.fire(n._value)}catch(o){}return r.PSD=e,n._catched}function f(){for(var n=0,t=this._deferreds.length;t>n;n++)o(this,this._deferreds[n]);this._deferreds=[]}function h(n,t,e,r){this.onFulfilled="function"==typeof n?n:null,this.onRejected="function"==typeof t?t:null,this.resolve=e,this.reject=r}function l(n,t,e,r){var o=!1;try{t(function(n){o||(o=!0,e(n))},function(t){return o?n._catched:(o=!0,r(t))})}catch(i){if(o)return;return r(i)}}var d=W.setImmediate||function(n){var t=e(arguments,1);setTimeout(function(){n.apply(W,t)},0)};b(function(){d=p=n=function(n){var t=arguments;setTimeout(function(){n.apply(W,e(t,1))},0)}});var p=d,y=!0,m=[],g=[];return r.on=v(null,"error"),r.all=function(){var n=e(1===arguments.length&&M(arguments[0])?arguments[0]:arguments);return new r(function(t,e){function r(i,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var c=u.then;if("function"==typeof c)return void c.call(u,function(n){r(i,n)},e)}n[i]=u,0===--o&&t(n)}catch(a){e(a)}}if(0===n.length)return t([]);for(var o=n.length,i=0;i<n.length;i++)r(i,n[i])})},r.prototype.then=function(n,t){var e=this,i=new r(function(r,i){null===e._state?o(e,new h(n,t,r,i)):p(o,e,new h(n,t,r,i))});return i._PSD=this._PSD,i.onuncatched=this.onuncatched,i._parent=this,i},r.prototype._then=function(n,t){o(this,new h(n,t,i,i))},r.prototype["catch"]=function(n){if(1===arguments.length)return this.then(null,n);var t=arguments[0],e=arguments[1];return"function"==typeof t?this.then(null,function(n){return n instanceof t?e(n):r.reject(n)}):this.then(null,function(n){return n&&n.name===t?e(n):r.reject(n)})},r.prototype["finally"]=function(n){return this.then(function(t){return n(),t},function(t){return n(),r.reject(t)})},r.prototype.onuncatched=null,r.resolve=function(n){if(n&&"function"==typeof n.then)return n;var t=new r(function(){});return t._state=!0,t._value=n,t},r.reject=function(n){var t=new r(function(){});return t._state=!1,t._value=n,t},r.race=function(n){return new r(function(t,e){n.map(function(n){n.then(t,e)})})},r.PSD=null,r.newPSD=function(n){var t=r.PSD;r.PSD=t?Object.create(t):{};try{return n()}finally{r.PSD=t}},r._rootExec=u,r._tickFinalize=function(n){if(y)throw new Error("Not in a virtual tick");g.push(n)},r}(),H=function(){},Y=!1;t(N).from(Error),o["delete"]=function(n){var t=new o(n),e=t["delete"]();return e.onblocked=function(n){return t.on("blocked",n),this},e},o.exists=function(n){return new o(n).open().then(function(n){return n.close(),!0},function(){return!1})},o.getDatabaseNames=function(n){return new J(function(n,t){var r=q();if(r){var o=r();o.onsuccess=function(t){n(e(t.target.result,0))},o.onerror=j(t)}else K(function(t){return n(t),!1})}).then(n)},o.defineClass=function(t){function e(e){e?n(this,e):Y&&E(this,t)}return e},o.applyStructure=E,o.ignoreTransaction=function(n){return J.newPSD(function(){return J.PSD.trans=null,n()})},o.vip=function(n){return J.newPSD(function(){return J.PSD.letThrough=!0,n()})},o.async=function(n){return function(){try{var t=I(n.apply(this,arguments));return t&&"function"==typeof t.then?t:o.Promise.resolve(t)}catch(e){return o.Promise.reject(e)}}},o.spawn=function(n,t,e){try{var r=I(n.apply(e,t||[]));return r&&"function"==typeof r.then?r:o.Promise.resolve(r)}catch(i){return o.Promise.reject(i)}},Object.defineProperty(o,"currentTransaction",{get:function(){return J.PSD&&J.PSD.trans||null}}),o.Promise=J,o.derive=t,o.extend=n,o.override=r,o.events=v,o.getByKeyPath=_,o.setByKeyPath=x,o.delByKeyPath=P,o.shallowClone=S,o.deepClone=D,o.addons=[],o.fakeAutoComplete=H,o.asap=m,o.ModifyError=N,o.MultiModifyError=N,o.IndexSpec=A,o.TableSchema=B,o.MaxKey=V;var G=W.idbModules&&W.idbModules.shimIndexedDB?W.idbModules:{};return o.dependencies={indexedDB:G.shimIndexedDB||W.indexedDB||W.mozIndexedDB||W.webkitIndexedDB||W.msIndexedDB,IDBKeyRange:G.IDBKeyRange||W.IDBKeyRange||W.webkitIDBKeyRange,Error:W.Error||String,SyntaxError:W.SyntaxError||String,TypeError:W.TypeError||String,localStorage:null!=("undefined"!=typeof chrome&&null!==chrome?chrome.storage:void 0)?null:W.localStorage},o.semVer="1.3.2",o.version=o.semVer.split(".").map(function(n){return parseInt(n)}).reduce(function(n,t,e){return n+t/Math.pow(10,2*e)}),b(function(){o.fakeAutoComplete=H=b,o.fake=Y=!0}),o["default"]=o,o});
//# sourceMappingURL=dist/dexie.min.js.map
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CacheEntry = CacheEntry;

var _comment = require('./comment');

var _dateTime = require('./date-time');

function CacheEntry() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  _comment.Comment.call(this, opts.comment);
  _dateTime.DateTime.call(this, 'expires', opts.expires, true);
  _dateTime.DateTime.call(this, 'lastAccess', opts.expires, true);

  Object.defineProperty(this, 'eTag', {
    enumerable: true,
    writable: true,
    value: opts.eTag
  });

  Object.defineProperty(this, 'hitCount', {
    enumerable: true,
    writable: true,
    value: opts.hitCount
  });
}

},{"./comment":2,"./date-time":6}],2:[function(require,module,exports){
'use strict';

// jshint unused:false

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Comment = Comment;
function Comment(comment) {
  Object.defineProperty(this, 'comment', {
    enumerable: true,
    writable: true,
    value: comment
  });
}

},{}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Content = Content;

var _comment = require('./comment');

var _util = require('./util');

// jshint unused:false
function Content() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  _comment.Comment.call(this, opts.comment);

  Object.defineProperty(this, 'size', {
    enumerable: true,

    get: function get() {
      if (this.text) {
        return _util.util.str2ab(this.text).byteLength;
      }

      return 0;
    },

    set: function set() {
      throw Error('not allowed');
    }
  });

  Object.defineProperty(this, 'compression', {
    enumerable: true,
    writable: true,
    value: opts.compression
  });

  Object.defineProperty(this, 'mimeType', {
    enumerable: true,
    writable: true,
    value: opts.mimeType || 'application/octet-stream'
  });

  Object.defineProperty(this, 'encoding', {
    enumerable: true,
    writable: true,
    value: opts.encoding
  });

  Object.defineProperty(this, 'text', {
    enumerable: true,
    writable: true,
    value: opts.text
  });
}

},{"./comment":2,"./util":16}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Cookie = Cookie;

var _comment = require('./comment');

var _dateTime = require('./date-time');

// jshint unused:false
function Cookie() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  if (!opts.name || !opts.value) {
    throw new Error('missing required fields');
  }

  _comment.Comment.call(this, opts.comment);
  _dateTime.DateTime.call(this, 'expires', opts.expires, true);

  Object.defineProperty(this, 'name', {
    enumerable: true,
    writable: true,
    value: opts.name
  });

  Object.defineProperty(this, 'value', {
    enumerable: true,
    writable: true,
    value: opts.value
  });

  Object.defineProperty(this, 'path', {
    enumerable: true,
    writable: true,
    value: opts.path
  });

  Object.defineProperty(this, 'domain', {
    enumerable: true,
    writable: true,
    value: opts.domain
  });

  Object.defineProperty(this, 'httpOnly', {
    enumerable: true,
    writable: true,
    value: typeof opts.httpOnly === 'boolean' ? opts.httpOnly : false
  });

  Object.defineProperty(this, 'secure', {
    enumerable: true,
    writable: true,
    value: typeof opts.secure === 'boolean' ? opts.secure : false
  });
}

},{"./comment":2,"./date-time":6}],5:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Creator = Creator;

var _comment = require('./comment');

var _version = require('./version');

// jshint unused:false
function Creator() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  if (!opts.name) {
    throw new Error('name required');
  }

  _comment.Comment.call(this, opts.comment);
  _version.Version.call(this, opts.version);

  Object.defineProperty(this, 'name', {
    enumerable: true,
    writable: true,
    value: opts.name
  });
}

},{"./comment":2,"./version":17}],6:[function(require,module,exports){
'use strict';

// jshint unused:false

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DateTime = DateTime;
function DateTime(name, value) {
  var date = new Date();

  switch (Object.prototype.toString.call(value)) {
    case '[object Undefined]':
      date = undefined;
      break;

    case '[object Date]':
      date = value;
      break;

    case '[object String]':
      date.setTime(Date.parse(value));
      break;

    case '[object Number]':
      date.setTime(value);
      break;
  }

  Object.defineProperty(this, name || 'dateTime', {
    enumerable: true,
    writable: true,
    value: date ? date.toISOString() : undefined
  });
}

},{}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Entry = Entry;

var _cacheEntry = require('./cache-entry');

var _comment = require('./comment');

var _dateTime = require('./date-time');

var _request = require('./request');

var _response = require('./response');

// jshint unused:false
function Entry() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  if (!opts.startedDateTime || !opts.request || !opts.response) {
    throw new Error('missing required fields');
  }

  opts.cache = opts.cache || {};
  opts.timings = opts.timings || {};

  _comment.Comment.call(this, opts.comment);
  _dateTime.DateTime.call(this, 'startedDateTime', opts.startedDateTime);

  Object.defineProperty(this, 'pageref', {
    enumerable: true,
    writable: true,
    value: opts.pageref
  });

  Object.defineProperty(this, 'time', {
    enumerable: true,
    writable: true,
    value: opts.time !== undefined ? opts.time : -1
  });

  Object.defineProperty(this, 'connection', {
    enumerable: true,
    writable: true,
    value: opts.connection
  });

  Object.defineProperty(this, 'serverIPAddress', {
    enumerable: true,
    writable: true,
    value: opts.serverIPAddress
  });

  Object.defineProperty(this, 'timings', {
    enumerable: true,
    writable: true,
    value: {
      blocked: opts.timings.blocked !== undefined ? opts.timings.blocked : -1,
      connect: opts.timings.connect !== undefined ? opts.timings.connect : -1,
      dns: opts.timings.dns !== undefined ? opts.timings.dns : -1,
      receive: opts.timings.receive !== undefined ? opts.timings.receive : -1,
      send: opts.timings.send !== undefined ? opts.timings.send : -1,
      wait: opts.timings.wait !== undefined ? opts.timings.wait : -1,
      comment: opts.timings.comment
    }
  });

  Object.defineProperty(this, 'cache', {
    enumerable: true,
    writable: true,
    value: {
      beforeRequest: opts.cache.beforeRequest ? opts.cache.beforeRequest instanceof _cacheEntry.CacheEntry ? opts.cache.beforeRequest : new _cacheEntry.CacheEntry(opts.cache.beforeRequest) : null,
      afterRequest: opts.cache.afterRequest ? opts.cache.afterRequest instanceof _cacheEntry.CacheEntry ? opts.cache.afterRequest : new _cacheEntry.CacheEntry(opts.cache.afterRequest) : null,
      comment: opts.cache.comment
    }
  });

  Object.defineProperty(this, 'request', {
    enumerable: true,

    get: function get() {
      return this._request;
    },

    set: function set(value) {
      value = value instanceof _request.Request ? value : new _request.Request(value);
      this._request = value;
    }
  });

  Object.defineProperty(this, 'response', {
    enumerable: true,

    get: function get() {
      return this._response;
    },

    set: function set(value) {
      value = value instanceof _response.Response ? value : new _response.Response(value);
      this._response = value;
    }
  });
  if (opts.request) {
    this.request = opts.request;
  } else if (opts._request) {
    this.request = opts._request;
  }
  if (opts.response) {
    this.response = opts.response;
  } else if (opts._response) {
    this.response = opts._response;
  }
}
/**
 * Associate existing page with this Entry object.
 */
Entry.prototype.setPage = function (page) {
  if (!page || !page.id) {
    throw new Error('The page does not have id property.');
  }
  this.pageref = page.id;
};
/**
 * Override toJSON behaviour so it will eliminate
 * all _* properies and replace it with a proper ones.
 */
Entry.prototype.toJSON = function () {
  var copy = Object.assign({}, this);
  var keys = Object.keys(copy);
  var under = keys.filter(function (key) {
    return key.indexOf('_') === 0;
  });
  under.forEach(function (key) {
    var realKey = key.substr(1);
    copy[realKey] = copy[key];
    delete copy[key];
  });
  return copy;
};

},{"./cache-entry":1,"./comment":2,"./date-time":6,"./request":14,"./response":15}],8:[function(require,module,exports){
'use strict';

var _cacheEntry = require('./cache-entry');

var _comment = require('./comment');

var _content = require('./content');

var _cookie = require('./cookie');

var _creator = require('./creator');

var _dateTime = require('./date-time');

var _entry = require('./entry');

var _log = require('./log');

var _page = require('./page');

var _pair = require('./pair');

var _param = require('./param');

var _postData = require('./post-data');

var _request = require('./request');

var _response = require('./response');

var _version = require('./version');

// jshint unused:false
var HAR = {
  Browser: _creator.Creator,
  CacheEntry: _cacheEntry.CacheEntry,
  Comment: _comment.Comment,
  Content: _content.Content,
  Cookie: _cookie.Cookie,
  Creator: _creator.Creator,
  DateTime: _dateTime.DateTime,
  Entry: _entry.Entry,
  Header: _pair.Pair,
  Log: _log.Log,
  Page: _page.Page,
  Param: _param.Param,
  PostData: _postData.PostData,
  Query: _pair.Pair,
  Request: _request.Request,
  Response: _response.Response,
  Version: _version.Version
};
module.exports = HAR;
window.HAR = HAR;

},{"./cache-entry":1,"./comment":2,"./content":3,"./cookie":4,"./creator":5,"./date-time":6,"./entry":7,"./log":9,"./page":10,"./pair":11,"./param":12,"./post-data":13,"./request":14,"./response":15,"./version":17}],9:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Log = Log;

var _comment = require('./comment');

var _creator = require('./creator');

var _entry = require('./entry');

var _page = require('./page');

var _version = require('./version');

function Log() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  // internal properties
  Object.defineProperties(this, {
    _pages: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    },

    _entries: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    }
  });

  _comment.Comment.call(this, opts.comment);
  _version.Version.call(this, opts.version);

  Object.defineProperty(this, 'creator', {
    enumerable: true,
    value: opts.creator instanceof _creator.Creator ? opts.creator : new _creator.Creator(opts.creator)
  });

  Object.defineProperty(this, 'browser', {
    enumerable: true,
    value: opts.browser ? opts.browser instanceof _creator.Creator ? opts.browser : new _creator.Creator(opts.browser) : undefined
  });

  Object.defineProperty(this, 'pages', {
    enumerable: true,

    get: function get() {
      return this._pages;
    },

    set: function set(pages) {
      this._pages = [];
      pages.forEach(this.addPage, this);
    }
  });

  Object.defineProperty(this, 'entries', {
    enumerable: true,

    get: function get() {
      return this._entries;
    },

    set: function set(entries) {
      this._entries = [];
      entries.forEach(this.addEntry, this);
    }
  });

  if (opts.pages) {
    opts.pages.forEach(this.addPage, this);
  } else if (opts._pages) {
    opts._pages.forEach(this.addPage, this);
  }

  if (opts.entries) {
    opts.entries.forEach(this.addEntry, this);
  } else if (opts._entries) {
    opts._entries.forEach(this.addEntry, this);
  }
}

Log.prototype.addPage = function (page) {
  page = page instanceof _page.Page ? page : new _page.Page(page);
  this._pages.push(page);
  return this;
};

Log.prototype.addEntry = function (entry, pageref) {
  entry.pageref = pageref || entry.pageref;
  entry = entry instanceof _entry.Entry ? entry : new _entry.Entry(entry);
  this._entries.push(entry);
  return this;
};
/**
 * Override toJSON behaviour so it will eliminate
 * all _* properies and replace it with a proper ones.
 */
Log.prototype.toJSON = function () {
  var copy = Object.assign({}, this);
  var keys = Object.keys(copy);
  var under = keys.filter(function (key) {
    return key.indexOf('_') === 0;
  });
  under.forEach(function (key) {
    var realKey = key.substr(1);
    copy[realKey] = copy[key];
    delete copy[key];
  });
  return copy;
};

},{"./comment":2,"./creator":5,"./entry":7,"./page":10,"./version":17}],10:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Page = Page;

var _comment = require('./comment');

var _dateTime = require('./date-time');

var _util = require('./util');

// jshint unused:false
function Page(options) {
  var opts = options || {};

  opts.pageTimings = opts.pageTimings || {};

  _comment.Comment.call(this, opts.comment);
  _dateTime.DateTime.call(this, 'startedDateTime', opts.startedDateTime);

  Object.defineProperty(this, 'id', {
    enumerable: true,
    writable: true,
    value: opts.id || _util.util.makeid(Math.ceil(10 / 2)).toString('hex').slice(0, 10)
  });

  Object.defineProperty(this, 'title', {
    enumerable: true,
    writable: true,
    value: opts.title || ''
  });

  Object.defineProperty(this, 'pageTimings', {
    enumerable: true,
    writable: true,
    value: {
      onLoad: opts.pageTimings.onLoad !== undefined ? opts.pageTimings.onLoad : -1,
      onContentLoad: opts.pageTimings.onContentLoad !== undefined ? opts.pageTimings.onContentLoad : -1
    }
  });
}

},{"./comment":2,"./date-time":6,"./util":16}],11:[function(require,module,exports){
'use strict';

var _typeof2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

var _typeof = typeof Symbol === "function" && _typeof2(Symbol.iterator) === "symbol" ? function (obj) {
  return typeof obj === "undefined" ? "undefined" : _typeof2(obj);
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj === "undefined" ? "undefined" : _typeof2(obj);
};

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Pair = Pair;

var _comment = require('./comment');

// jshint unused:false
function Pair(name, value, comment) {
  var opts = {
    name: name,
    value: value,
    comment: comment
  };

  if ((typeof name === 'undefined' ? 'undefined' : _typeof(name)) === 'object') {
    opts = name;
  }

  _comment.Comment.call(this, opts.comment);

  Object.defineProperty(this, 'name', {
    enumerable: true,
    writable: true,
    value: opts.name || ''
  });

  Object.defineProperty(this, 'value', {
    enumerable: true,
    writable: true,
    value: opts.value || ''
  });
}

},{"./comment":2}],12:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Param = Param;

var _comment = require('./comment');

// jshint unused:false
function Param() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  _comment.Comment.call(this, opts.comment);

  Object.defineProperty(this, 'name', {
    enumerable: true,
    writable: true,
    value: opts.name || ''
  });

  Object.defineProperty(this, 'value', {
    enumerable: true,
    writable: true,
    value: opts.value || ''
  });

  Object.defineProperty(this, 'contentType', {
    enumerable: true,
    writable: true,
    value: opts.contentType || undefined
  });

  Object.defineProperty(this, 'fileName', {
    enumerable: true,
    writable: true,
    value: opts.fileName || undefined
  });
}

},{"./comment":2}],13:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PostData = PostData;

var _comment = require('./comment');

var _param = require('./param');

function PostData() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  // internal properties
  Object.defineProperties(this, {
    _params: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    }
  });

  _comment.Comment.call(this, opts.comment);

  Object.defineProperty(this, 'mimeType', {
    enumerable: true,
    writable: true,
    value: opts.mimeType || 'application/octet-stream'
  });

  Object.defineProperty(this, 'text', {
    enumerable: true,
    writable: true,
    value: opts.text || ''
  });

  Object.defineProperty(this, 'params', {
    enumerable: true,

    get: function get() {
      return this._params;
    },

    set: function set(params) {
      this._params = [];
      params.forEach(this.addParam, this);
    }
  });

  if (opts.params) {
    opts.params.forEach(this.addParam, this);
  }
}

PostData.prototype.addParam = function (param) {
  this._params.push(new _param.Param(param));

  return this;
};
/**
 * Override toJSON behaviour so it will eliminate
 * all _* properies and replace it with a proper ones.
 */
PostData.prototype.toJSON = function () {
  var copy = Object.assign({}, this);
  var keys = Object.keys(copy);
  var under = keys.filter(function (key) {
    return key.indexOf('_') === 0;
  });
  under.forEach(function (key) {
    var realKey = key.substr(1);
    copy[realKey] = copy[key];
    delete copy[key];
  });
  return copy;
};

},{"./comment":2,"./param":12}],14:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Request = Request;

var _comment = require('./comment');

var _cookie = require('./cookie');

var _pair = require('./pair');

var Header = _interopRequireWildcard(_pair);

var Query = _interopRequireWildcard(_pair);

var _postData = require('./post-data');

var _util = require('./util');

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  } else {
    var newObj = {};if (obj != null) {
      for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
      }
    }newObj.default = obj;return newObj;
  }
}

// jshint unused:false
function Request() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  if (!opts.url) {
    throw new Error('url required');
  }

  // internal properties
  Object.defineProperties(this, {
    _headers: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    },

    _queryString: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    },

    _cookies: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    },

    _postData: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: new _postData.PostData()
    },

    _url: {
      enumerable: true,
      configurable: false,
      writable: true,
      value: ''
    }
  });

  _comment.Comment.call(this, opts.comment);

  Object.defineProperty(this, 'method', {
    enumerable: true,
    value: opts.method || ''
  });

  Object.defineProperty(this, 'url', {
    enumerable: true,

    get: function get() {
      return this._url;
    },

    set: function set(url) {
      var _this = this;

      this._url = url;
      var parser = document.createElement('a');
      parser.href = url;
      if (parser.search.length > 0) {
        var params = parser.search.substr(1).split(/[&|;]/gi);
        params.forEach(function (param) {
          var parts = param.split('=');
          _this.addQuery({
            name: parts[0],
            value: parts[1]
          });
        });
      }
    }
  });

  Object.defineProperty(this, 'httpVersion', {
    enumerable: true,
    value: opts.httpVersion || ''
  });

  Object.defineProperty(this, 'headersSize', {
    enumerable: true,

    get: function get() {
      var headers = _util.util.toObject(this._headers);
      var keys = Object.keys(headers);

      var values = keys.map(function (key) {
        return headers[key];
      });

      var headersString = this.method + this.url + keys.join() + values.join();

      // startline: [method] [url] HTTP/1.1\r\n = 12
      // endline: \r\n = 2
      // every header + \r\n = * 2
      // add 2 for each combined header
      return _util.util.str2ab(headersString).byteLength + keys.length * 2 + 2 + 12 + 2;
    },

    set: function set() {
      throw Error('not allowed');
    }
  });

  Object.defineProperty(this, 'bodySize', {
    enumerable: true,

    get: function get() {
      if (this._postData && this._postData.text) {
        return _util.util.str2ab(this._postData.text).byteLength;
      }

      return 0;
    },

    set: function set() {
      throw Error('not allowed');
    }
  });

  Object.defineProperty(this, 'postData', {
    enumerable: true,

    get: function get() {
      return this._postData;
    },

    set: function set(postData) {
      postData = postData instanceof _postData.PostData ? postData : new _postData.PostData(postData);
      this._postData = postData;
    }
  });

  Object.defineProperty(this, 'headers', {
    enumerable: true,

    get: function get() {
      return this._headers;
    },

    set: function set(headers) {
      this._headers = [];
      headers.forEach(this.addHeader, this);
    }
  });

  Object.defineProperty(this, 'queryString', {
    enumerable: true,

    get: function get() {
      return this._queryString;
    },

    set: function set(queryString) {
      this._queryString = [];
      queryString.forEach(this.addQuery, this);
    }
  });

  Object.defineProperty(this, 'cookies', {
    enumerable: true,

    get: function get() {
      return this._cookies;
    },

    set: function set(cookies) {
      this._cookies = [];
      cookies.forEach(this.addCookie, this);
    }
  });

  if (opts.url) {
    this.url = opts.url;
  } else if (opts._url) {
    this.url = opts._url;
  }

  if (opts.headers) {
    opts.headers.forEach(this.addHeader, this);
  } else if (opts._headers) {
    opts._headers.forEach(this.addHeader, this);
  }

  if (opts.queryString) {
    opts.queryString.forEach(this.addQuery, this);
  } else if (opts._queryString) {
    opts._queryString.forEach(this.addQuery, this);
  }

  if (opts.cookies) {
    opts.cookies.forEach(this.addCookie, this);
  } else if (opts._cookies) {
    opts._cookies.forEach(this.addCookie, this);
  }

  if (opts.postData) {
    this.postData = opts.postData;
  } else if (opts._postData) {
    this.postData = opts._postData;
  }
}

Request.prototype.addHeader = function (header) {
  header = header instanceof Header.Pair ? header : new Header.Pair(header);
  this._headers.push(header);
  return this;
};

Request.prototype.addQuery = function (query) {
  query = query instanceof Query.Pair ? query : new Query.Pair(query);
  this._queryString.push(query);
  return this;
};

Request.prototype.addCookie = function (options) {
  options = options instanceof _cookie.Cookie ? options : new _cookie.Cookie(options);
  this._cookies.push(options);
  return this;
};
/**
 * Override toJSON behaviour so it will eliminate
 * all _* properies and replace it with a proper ones.
 */
Request.prototype.toJSON = function () {
  var copy = Object.assign({}, this);
  var keys = Object.keys(copy);
  var under = keys.filter(function (key) {
    return key.indexOf('_') === 0;
  });
  under.forEach(function (key) {
    var realKey = key.substr(1);
    copy[realKey] = copy[key];
    delete copy[key];
  });
  return copy;
};

},{"./comment":2,"./cookie":4,"./pair":11,"./post-data":13,"./util":16}],15:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Response = Response;

var _comment = require('./comment');

var _content = require('./content');

var _cookie = require('./cookie');

var _pair = require('./pair');

var Header = _interopRequireWildcard(_pair);

var _util = require('./util');

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  } else {
    var newObj = {};if (obj != null) {
      for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
      }
    }newObj.default = obj;return newObj;
  }
}

/* global Content, util, Header, Cookie */
// jshint unused:false
function Response() {
  var opts = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

  if (!opts.status || !opts.statusText) {
    throw new Error('missing required fields');
  }

  // internal properties
  Object.defineProperties(this, {
    _headers: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    },

    _cookies: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: []
    },

    _content: {
      enumerable: false,
      configurable: false,
      writable: true,
      value: new _content.Content()
    }
  });

  _comment.Comment.call(this, opts.comment);

  Object.defineProperty(this, 'status', {
    enumerable: true,
    value: opts.status
  });

  Object.defineProperty(this, 'statusText', {
    enumerable: true,
    value: opts.statusText
  });

  Object.defineProperty(this, 'httpVersion', {
    enumerable: true,
    value: opts.httpVersion || 'HTTP/1.1'
  });

  Object.defineProperty(this, 'redirectURL', {
    enumerable: true,
    value: opts.redirectURL || ''
  });

  Object.defineProperty(this, 'headersSize', {
    enumerable: true,

    get: function get() {
      var headers = _util.util.toObject(this._headers);
      var keys = Object.keys(headers);

      var values = keys.map(function (key) {
        return headers[key];
      });

      var headersString = keys.join() + values.join();

      // endline: \r\n = 2
      // every header + \r\n = * 2
      // add 2 for each combined header
      return _util.util.str2ab(headersString).byteLength + keys.length * 2 + 2 + 2;
    },

    set: function set() {
      throw Error('not allowed');
    }
  });

  Object.defineProperty(this, 'bodySize', {
    enumerable: true,

    get: function get() {
      return this._content.size;
    },

    set: function set() {
      throw Error('not allowed');
    }
  });

  Object.defineProperty(this, 'content', {
    enumerable: true,

    get: function get() {
      return this._content;
    },

    set: function set(content) {
      content = content instanceof _content.Content ? content : new _content.Content(content);
      this._content = content;
    }
  });

  Object.defineProperty(this, 'headers', {
    enumerable: true,

    get: function get() {
      return this._headers;
    },

    set: function set(headers) {
      this._headers = [];
      headers.forEach(this.addHeader, this);
    }
  });

  Object.defineProperty(this, 'cookies', {
    enumerable: true,

    get: function get() {
      return this._cookies;
    },

    set: function set(cookies) {
      this._cookies = [];
      cookies.forEach(this.addCookie, this);
    }
  });
  if (opts.headers) {
    opts.headers.forEach(this.addHeader, this);
  } else if (opts._headers) {
    opts._headers.forEach(this.addHeader, this);
  }
  if (opts.cookies) {
    opts.cookies.forEach(this.addCookie, this);
  } else if (opts._cookies) {
    opts._cookies.forEach(this.addCookie, this);
  }
  if (opts.content) {
    this.content = opts.content;
  } else if (opts._content) {
    this.content = opts._content;
  }
}

Response.prototype.addHeader = function (header) {
  header = header instanceof Header.Pair ? header : new Header.Pair(header);
  this._headers.push(header);
  return this;
};

Response.prototype.addCookie = function (options) {
  options = options instanceof _cookie.Cookie ? options : new _cookie.Cookie(options);
  this._cookies.push(options);
  return this;
};
/**
 * Override toJSON behaviour so it will eliminate
 * all _* properies and replace it with a proper ones.
 */
Response.prototype.toJSON = function () {
  var copy = Object.assign({}, this);
  var keys = Object.keys(copy);
  var under = keys.filter(function (key) {
    return key.indexOf('_') === 0;
  });
  under.forEach(function (key) {
    var realKey = key.substr(1);
    copy[realKey] = copy[key];
    delete copy[key];
  });
  return copy;
};

},{"./comment":2,"./content":3,"./cookie":4,"./pair":11,"./util":16}],16:[function(require,module,exports){
'use strict';

// jshint unused:false

Object.defineProperty(exports, "__esModule", {
  value: true
});
var util = exports.util = {
  toObject: function toObject(array) {
    return array.reduce(function (obj, pair) {
      if (obj[pair.name] === undefined) {
        obj[pair.name] = pair.value;
        return obj;
      }

      // convert to array
      var arr = [obj[pair.name], pair.value];

      obj[pair.name] = arr;

      return obj;
    }, {});
  },

  toArray: function toArray(obj) {
    return Object.keys(obj).map(function (name) {
      return {
        name: name,
        value: obj[name]
      };
    });
  },

  str2ab: function str2ab(str) {
    var buf = new ArrayBuffer(str.length * 2); // 2 bytes for each char
    var bufView = new Uint16Array(buf);
    for (var i = 0, strLen = str.length; i < strLen; i++) {
      bufView[i] = str.charCodeAt(i);
    }
    return buf;
  },

  makeid: function makeid(size) {
    if (typeof size !== 'number') {
      throw new Error('Size must be a number');
    }
    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < size; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return text;
  }
};

},{}],17:[function(require,module,exports){
'use strict';

// jshint unused:false

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Version = Version;
function Version(version) {
  if (!version) {
    throw new Error('version required');
  }

  Object.defineProperty(this, 'version', {
    enumerable: true,
    writable: true,
    value: version.toString()
  });
}

},{}]},{},[8])
'use strict';
/*******************************************************************************
 * Copyright 2012 Pawel Psztyc
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 ******************************************************************************/

/**
 * Advanced Rest Client namespace
 */
var arc = arc || {};
/**
 * ARC app's namespace
 */
arc.app = arc.app || {};
/**
 * A namespace for the utilis functions
 */
arc.app.utils = {};
/**
 * Generate a RFC4122, version 4 ID. Example:
 * "92329D39-6F5C-4520-ABFC-AAB64544E172"
 * http://stackoverflow.com/a/21963136/1127848
 * @return {String} The UUID string.
 */
arc.app.utils.uuid = function() {
  // jscs:disable
  /* jshint ignore:start */
  var lut = [];
  for (var i = 0; i < 256; i++) {
    lut[i] = (i < 16 ? '0' : '') + (i).toString(16);
  }
  var fn = function() {
    var d0 = Math.random() * 0xffffffff | 0;
    var d1 = Math.random() * 0xffffffff | 0;
    var d2 = Math.random() * 0xffffffff | 0;
    var d3 = Math.random() * 0xffffffff | 0;
    return lut[d0 & 0xff] + lut[d0 >> 8 & 0xff] + lut[d0 >> 16 & 0xff] +
      lut[d0 >> 24 & 0xff] + '-' + lut[d1 & 0xff] + lut[d1 >> 8 & 0xff] + '-' +
      lut[d1 >> 16 & 0x0f | 0x40] + lut[d1 >> 24 & 0xff] + '-' + lut[d2 & 0x3f | 0x80] +
      lut[d2 >> 8 & 0xff] + '-' + lut[d2 >> 16 & 0xff] + lut[d2 >> 24 & 0xff] +
      lut[d3 & 0xff] + lut[d3 >> 8 & 0xff] + lut[d3 >> 16 & 0xff] + lut[d3 >> 24 & 0xff];
  };
  return fn();
  // jscs:enable
  /* jshint ignore:end */
};
/**
 * This function will search for links in the `input` and replace it with anchor.
 *
 * @param {String} input A search string
 * @return {String} Parsed string.
 */
arc.app.utils.autoLink = function(input) {
  var r = new RegExp('(https?:\\/\\/([^" >]*))', 'gim');
  return input.replace(r, '<a target="_blank" class="auto-link" href="$1">$1</a>');
};
/**
 * Escape characters to display HTML code.
 *
 * @return {String} Encoded string.
 */
arc.app.utils.encodeHtml = function(input) {
  if (typeof input !== 'string') {
    return input;
  }
  return input.replace(/</g, '&lt;').replace(/>/g, '&gt;');
};
arc.app.utils._chromeVersion = null;
/**
 * Get Chrome full version.
 *
 * @type {String} A full version or `(not set)` is can't find.
 */
Object.defineProperty(arc.app.utils, 'chromeVersion', {
  enumerable: true,

  get: function() {
    if (arc.app.utils._chromeVersion) {
      return arc.app.utils._chromeVersion;
    }
    var raw = navigator.userAgent.match(/Chrom[e|ium]\/([0-9\.]+)/);
    arc.app.utils._chromeVersion = raw ? raw[1] : '(not set)';
    return arc.app.utils._chromeVersion;
  },

  set: function() {
    throw new Error('appVer can\'t be overrited.');
  }
});
arc.app.utils._appVer = null;
/**
 * Get ARC version from the manifest file.
 *
 * @type {String} An ARC version.
 */
Object.defineProperty(arc.app.utils, 'appVer', {
  enumerable: true,

  get: function() {
    if (arc.app.utils._appVer) {
      return arc.app.utils._appVer;
    }
    if (!chrome || !chrome.runetime || !chrome.runtime.getManifest) {
      //testing
      arc.app.utils._appVer = '5.0.5-test';
    } else {
      arc.app.utils._appVer = chrome.runtime.getManifest().version;
    }
    return arc.app.utils._appVer;
  },

  set: function() {
    throw new Error('appVer can\'t be overrited.');
  }
});

'use strict';
/*******************************************************************************
 * Copyright 2012 Pawel Psztyc
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 ******************************************************************************/
/* global HAR */

/**
 * A base types definitions for the app.
 */

/**
 * A base object for all types with helper methods.
 */
class BaseObject {

  /**
   * Check if [passed] object contains all required properties declared in [required] array.
   * This method will throw an [Error] when required parameter is missing.
   *
   * @param {Array<String>} required An array of required parameters.
   * @param {Object} passed An object on which test properties
   */
  assertRequiredKeys(required, passed) {
    const errors = [];
    required.forEach((name) => {
      if (!(name in passed)) {
        errors.push(name);
      }
    });
    if (errors.length > 0) {
      throw new Error('Missing parameters: ' + errors.join(', ') + '.');
    }
  }

  /**
   * Override toJSON behaviour so it will eliminate
   * all _* properies and replace it with a proper ones.
   */
  toJSON() {
    var copy = Object.assign({}, this);
    var keys = Object.keys(copy);
    var under = keys.filter((key) => key.indexOf('_') === 0);
    under.forEach((key) => {
      let realKey = key.substr(1);
      copy[realKey] = copy[key];
      delete copy[key];
    });
    return copy;
  }
}
/**
 * OrderedList object represents an object that can be ordered in a list. This
 * objects have additional properties and methods to manage their position on
 * the list.
 *
 * @example <caption>Reordering elements on list</caption>
 * // Initial list
 * let list = [OrderedList1, OrderedList2, OrderedList3, OrderedList4, OrderedList5, OrderedList6,
 * OrderedList7];
 * // Last element must be moved from 7-th position to 3-rd (zero-based)
 * list.forEach((item) => {
 *  item.changeOrder('up', 2, list[6], list[6].order);
 * });
 * // [OrderedList1, OrderedList2, OrderedList7, OrderedList3, OrderedList4, OrderedList5,
 * OrderedList6]
 * @extends BaseObject
 */
class OrderedList extends BaseObject {

  constructor(opts) {
    super(opts);
    /**
     * Object order on a list
     *
     * @type {Number}
     * @default 0
     */
    this.order = opts.order || 0;
  }
  /**
   * Change the order of the element. This method will change the order of the
   * element depending on arguments. Note that this method don't care on which
   * list item is. Program should perform this operation only on elements that
   * are already on the list. Object that is changing position can also be
   * changed using this method so it's safe to use it on all list elements.
   *
   *
   *
   * @example <caption>Reordering elements on list</caption>
   * //For example if you want to move element from position 7 to position 2.
   * //The function should look as follows:
   *
   * // Initial list
   * let list = [OrderedList1, OrderedList2, OrderedList3, OrderedList4, OrderedList5,
   * OrderedList6, OrderedList7];
   * // Last element must be moved from 7-th position to 3-rd (zero-based)
   * list.forEach((item) => {
   *  item.changeOrder('up', 2, list[6], list[6].order);
   * });
   * // [OrderedList1, OrderedList2, OrderedList7, OrderedList3, OrderedList4, OrderedList5,
   * OrderedList6]
   * Note: positions (order) are zero-based.
   *
   * @param {String} dir  The direction of the change. Set to `up` if the
   * element should go up on the list or `down` (default) otherwise.
   * @param {Number} change  A target position of the moved element. If the
   * element should finally be at position 2 this value should be 2.
   * @param {OrderedList} moved  A moved OrderedList object as a reference to
   * compare if current object is moved object.
   * @param {Number} movedOrder  A base position of the moved element. If
   * moved element previously was at position 7 this value should be 7.
   */
  changeOrder(dir, change, moved, movedOrder) {
    if (dir === 'up') {
      if (this.order === 0) {
        throw new Error('Can\'t move list element below 0 in this direction.');
      }
      this.moveUp(change, moved, movedOrder);
    } else {
      this.moveDown(change, moved, movedOrder);
    }
  }
  /**
   * Decrement order value so the element will go up on the list.
   * This method is used internally by {@link OrderedList#changeOrder} method.
   *
   * @example
   * Object.moveUp(2, OtherObject, 4);
   *
   * @param {Number} change  A target position of the moved element. If the
   * element should finally be at position 2 this value should be 2.
   * @param {OrderedList} moved  A moved OrderedList object as a reference to
   * compare if current object is moved object.
   * @param {Number} movedOrder  A base position of the moved element. If
   * moved element previously was at position 7 this value should be 7.
   */
  moveUp(change, moved, movedOrder) {
    if (this.order < change) {
      return;
    }
    if (this.order > movedOrder) {
      return;
    }
    if (this === moved) {
      this.order = change;
      return;
    }
    --this.order;
  }
  /**
   * Increment order value so the element will go down on the list.
   * This method is used internally by {@link OrderedList#changeOrder} method.
   *
   * @example
   * Object.moveUp(2, OtherObject, 4);
   *
   * @param {Number} change  A target position of the moved element. If the
   * element should finally be at position 2 this value should be 2.
   * @param {OrderedList} moved  A moved OrderedList object as a reference to
   * compare if current object is moved object.
   * @param {Number} movedOrder  A base position of the moved element. If
   * moved element previously was at position 7 this value should be 7.
   */
  moveDown(change, moved, movedOrder) {
    if (this.order > change) {
      return;
    }
    if (this.order < movedOrder) {
      return;
    }
    if (this === moved) {
      this.order = change;
      return;
    }
    ++this.order;
  }
  toJSON() {
    return super.toJSON();
  }
}
/**
 * A base class for request object.
 * This object will be stored in the database.
 *
 * @extends OrderedList
 * @throws {Error} If `url`, `method` or `type` is not available to the constructor.
 */
class RequestObject extends OrderedList {
  /**
   * To construct RequestObject client need an URL, method and type defined.
   * A type can be one of 'saved', 'history' or 'drive'.
   * If a type is 'drive' then driveId property must be set.
   *
   * RequestObjects may not have id property when it's newly created object or
   * when object was restored from Drive and not yet saved locally.
   */
  constructor(opts) {
    super(opts);
    super.assertRequiredKeys(['url', 'method', 'type'], opts);
    if (opts.id) {
      /**
       * A database ID.
       * It can be null / undefined if the object wasn't saved yet.
       *
       * @type {Number}
       */
      this.id = opts.id;
    }
    /**
     * A HAR object containing request info.
     * To initialize this object use helper class HAR:
     * `new HAR.Log({ ... })` or just pass a JSON object according to HAR specification.
     *
     * @type {HAR}
     */
    this._har = opts._har ? (opts._har instanceof HAR.Log) ? opts._har :
      new HAR.Log(opts._har) : null;
    /**
     * A name of the request.
     * It is repeated in the HAR object - according to HAR spec in the pages array of the
     * log object. It must be in the non-array path to index the value in the IDB engine.
     * @type {!String}
     */
    this._name = null;
    /**
     * Request URL. It's an index and part of keyPath in the database. Therefore it's required.
     *
     * @type {!String}
     */
    this.url = opts.url;
    /**
     * Request HTTP method.
     * It's an index and part of keyPath in the database. Therefore it's required.
     *
     * @type {!String}
     */
    this.method = opts.method;
    /**
     * A type of the object. Sub classes can set it by default.
     * Used to distinguish what kind of request is this (saved, history)
     *
     * @type {!String}
     */
    this.type = opts.type;
    // set a har object
    if (opts.har) {
      this.har = opts.har;
    }
    // Set a name value.
    if (opts.name) {
      this.name = opts.name;
    }
  }

  set har(har) {
    if (har instanceof HAR.Log) {
      this._har = har;
    } else {
      this._har = new HAR.Log(har);
    }
  }

  get har() {
    return this._har;
  }

  set name(name) {
    this._name = String(name);
    if (this._har) {
      this._har.pages[0].title = this._name;
    }
  }

  get name() {
    return this._name;
  }

  toJSON() {
    return super.toJSON();
  }
}
/**
 * A class of saved requests objects.
 * It's just a shorthand class.
 *
 * @example <caption>Creating this class id the same as</caption>
 * let ro = new RequestObject(...);
 * ro.type = 'saved';
 *
 * @extends RequestObject
 */
// jshint unused:false
class SavedRequestObject extends RequestObject {
  constructor(opts) {
    opts.type = 'saved';
    super(opts);
  }
  toJSON() {
    return super.toJSON();
  }
}
/**
 * A class of history requests objects.
 * It's just a shorthand class, enlivenment for:
 *
 * @example <caption>Creating this class id the same as</caption>
 * let ro = new RequestObject(...);
 * ro.type = 'history';
 *
 * @extends RequestObject
 */
// jshint unused:false
class HistoryRequestObject extends RequestObject {
  constructor(opts) {
    opts.type = 'history';
    super(opts);
  }
  toJSON() {
    return super.toJSON();
  }
}
/**
 * A class of drive requests object.
 * It's just a shorthand class, enlivenment for:
 *
 * @example <caption>Creating this class id the same as</caption>
 * let ro = new RequestObject(...);
 * ro.type = 'drive';
 *
 * @extends RequestObject
 */
// jshint unused:false
class DriveRequestObject extends RequestObject {
  constructor(opts) {
    opts.type = 'drive';
    super(opts);
    /**
     * Google Drive ID.
     *
     * @type {String}
     */
    this.driveId = opts.driveId;
  }
  toJSON() {
    return super.toJSON();
  }
}
/**
 * Creates a new base request object stored in the local store.
 * It's different than RequestObject to quickly access latest request data
 * without querying IDB. It also simplifies logic.
 * Request object is created on demand during save.
 *
 * This object ment to be stored in local storage and support request view editors.
 */
class RequestLocalObject extends BaseObject {
  constructor(opts) {
    super(opts);
    /**
     * An url of the request.
     *
     * @type {String}
     */
    this.url = opts.url || '';
    /**
     * A HTTP method
     *
     * @type {String}
     */
    this.method = opts.method || 'GET';
    /**
     * A HTTP message part with the string values.
     *
     * @type {String}
     */
    this.headers = opts.headers || '';
    /**
     * A payload of the request.
     *
     * @type {Any}
     */
    this.payload = opts.payload || undefined;
    /**
     * (Optional) True if original request that created this object originated from saved request,
     * may be not set. If `isSaved` and `isDrive` is false then the object represents
     * history object.
     *
     * @type {Boolean}
     */
    this.isSaved = opts.isSaved || false;
    /**
     * (Optional) True if original request that created this object originated from google drive.
     *
     * @type {Boolean}
     */
    this.isDrive = opts.isDrive || false;
    /**
     * (Optional) Type depends on isSaved, the ID of the original object.
     *
     * @type {Number}
     */
    this.id = opts.id || undefined;
    /**
     * Drive items are stored like saved request. They have additional attribute `driveId`.
     *
     * @type {String}
     */
    this.driveId = opts.driveId || undefined;
  }
}
/**
 * A class representing an entity in the data store with information
 * about export to app server.
 *
 * @extends BaseObject
 * @throws {Error} If `serverId` or `requestId` is not available to the constructor.
 */
// jshint unused:false
class ServerExportedObject extends BaseObject {

  constructor(opts) {
    super(opts);

    super.assertRequiredKeys(['serverId', 'requestId'], opts);
    /**
     * An id of the item on the server.
     *
     * @type {String}
     */
    this.serverId = opts.serverId;
    /**
     * RequestObject data store id.
     *
     * @type {String}
     */
    this.requestId = opts.requestId;
  }
}
/**
 * A class representing an URL.
 *
 * @extends BaseObject
 * @throws {Error} If `url` is not available to the constructor.
 */
class UrlObject extends BaseObject {

  constructor(opts) {
    super();
    super.assertRequiredKeys(['url'], opts);
    /**
     * An URL to store. It's a database key path so it must be unique.
     *
     * @type {!String}
     */
    this.url = opts.url;
    /**
     * Last used time as a number of milliseconds
     *
     * @type {Number}
     */
    this.time = opts.time;
  }
}
/**
 * A class representing an entity in the URL history data store.
 *
 * @extends UrlObject
 */
// jshint unused:false
class HistoryUrlObject extends UrlObject {
  constructor(opts) {
    super(opts);
  }
}
/**
 * A class representing an entity in the socket urls history data store.
 *
 * @extends UrlObject
 */
// jshint unused:false
class HistorySocketObject extends UrlObject {
  constructor(opts) {
    super(opts);
  }
}
/**
 * A class representing and entity in the Projects data store.
 *
 * @extends OrderedList
 * @throws {Error} If `requestIds` is not undefined but is not an Array.
 */
// jshint unused:false
class ProjectObject extends OrderedList {

  constructor(opts) {
    super(opts);

    if (!opts.requestIds) {
      opts.requestIds = [];
    }
    if (typeof opts.requestIds.length === 'undefined') {
      throw new Error('`requestIds` property must be an array of ids of request objects');
    }
    if (opts.id) {
      /**
       * A database ID.
       * It can be null / undefined if the object wasn't saved yet.
       *
       * @type {Number}
       */
      this.id = opts.id;
    }
    /**
     * A list of all endpoints (RequestObjects) referenced to this project.
     *
     * @type {Array}
     */
    this.requestIds = opts.requestIds;
    /**
     * Project name
     *
     * @type {String}
     */
    this.name = opts.name;
    /**
     * Project creation time.
     *
     * @type {Date}
     */
    this.created = opts.time ? new Date(opts.time) : opts.created ? opts.created : new Date();
  }

  /**
   * Append request id to the list of ids.
   *
   * @param {Number} requestIds An ID of the request object.
   */
  addRequest(requestIds) {
    if (!requestIds) {
      throw new Error('Request ID must be set.');
    }
    this.requestIds.push(requestIds);
  }
}
/**
 * A HTTP status code representation in the storage.
 *
 * @extends BaseObject
 * @throws {Error} If `key` or `label` is not available to the constructor.
 */
// jshint unused:false
class HttpStatusObject extends BaseObject {
  constructor(opts) {
    super();

    super.assertRequiredKeys(['key', 'label'], opts);
    /**
     * A HTTP status code is represented as `key`
     *
     * @type {Number}
     */
    this.key = opts.key;
    /**
     * A status message associated with this code.
     *
     * @type {String}
     */
    this.label = opts.label;
    /**
     * An optional description for this code.
     *
     * @type {String}
     */
    this.desc = opts.desc ? opts.desc : undefined;
  }
}
/**
 * A HTTP header representation in the storage.
 *
 * @extends BaseObject
 * @throws {Error} If `key` or `type` is not available to the constructor.
 */
// jshint unused:false
class HttpHeaderObject extends BaseObject {
  constructor(opts) {
    super();

    super.assertRequiredKeys(['key', 'type'], opts);
    /**
     * Header name.
     *
     * @type {String}
     */
    this.key = opts.key;
    /**
     * Header type. One of `request` or `response`.
     *
     * @type {String}
     */
    this.type = opts.type;
    /**
     * An optional example for this header.
     *
     * @type {String}
     */
    this.example = opts.example ? opts.example : undefined;
    /**
     * An optional description for this header.
     *
     * @type {String}
     */
    this.desc = opts.desc ? opts.desc : undefined;
  }
}
/**
 * A class representing data export object.
 * This object will be used to export data to file as a structure wrapper.
 *
 * @extends BaseObject
 */
class FileExport extends BaseObject {
  constructor(opts) {
    super();
    this.kind = 'ARC#requestsDataExport';
    this.createdAt = new Date();
    this.version = arc.app.utils.appVer;

    if (!(opts.requests instanceof Array)) {
      console.warn('The opts.requests is not an array. Overriding');
      opts.requests = [];
    }
    if (!(opts.projects instanceof Array)) {
      console.warn('The opts.projects is not an array. Overriding');
      opts.projects = [];
    }
    opts.requests.forEach((item) => item.kind = 'ARC#RequestObject');
    opts.projects.forEach((item) => item.kind = 'ARC#ProjectObject');

    this.requests = opts.requests;
    this.projects = opts.projects;
  }
}
/**
 * A class representing a magic variable stored in the database.
 */
class MagicVariableObject extends BaseObject {
  constructor(opts) {
    super();
    //this.id = undefined;
    this.variable = opts.variable || undefined;
    this.value = opts.value || undefined;
    this.type = opts.type || 'global';
    this.project = opts.project || undefined;
  }
}

window.RequestObject = RequestObject;
window.SavedRequestObject = SavedRequestObject;
window.HistoryRequestObject = HistoryRequestObject;
window.DriveRequestObject = DriveRequestObject;
window.ProjectObject = ProjectObject;
window.FileExport = FileExport;
window.RequestLocalObject = RequestLocalObject;

'use strict';
/*******************************************************************************
 * Copyright 2012 Pawel Psztyc
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 ******************************************************************************/

/* global Dexie, chrome, HistoryUrlObject, HistorySocketObject, ProjectObject,
 ServerExportedObject, RequestObject, HttpStatusObject, HttpHeaderObject, MagicVariableObject */
window.pendingAnalytics = window.pendingAnalytics || [];
/**
 * Advanced Rest Client namespace
 *
 * @namespace
 */
var arc = arc || {};
/**
 * ARC app's namespace
 *
 * @namespace
 */
arc.app = arc.app || {};
/**
 * A namespace for the database scripts.
 *
 * @namespace
 */
arc.app.db = arc.app.db || {};

/**
 * A namespace for IndexedDB scripts.
 *
 * @namespace
 */
arc.app.db.idb = {};
/**
 * A namespace for request objects queries..
 *
 * @namespace
 */
arc.app.db.idb.requests = {};
/**
 * A namespace for projects queries
 *
 * @namespace
 */
arc.app.db.idb.projects = {};
/**
 * A namespace for websocket history urls queries
 *
 * @namespace
 */
arc.app.db.idb.websockets = {};
/**
 * A namespace for status codes definitions queries
 *
 * @namespace
 */
arc.app.db.idb.statuses = {};
/**
 * A namespace for headers definitions queries
 *
 * @namespace
 */
arc.app.db.idb.headers = {};
/**
 * A namespace for exported to app server data queries
 *
 * @namespace
 */
arc.app.db.idb.exported = {};
/**
 * A namespace for url history queries
 *
 * @namespace
 */
arc.app.db.idb.urls = {};
/**
 * Open the database.
 *
 * @returns {Promise} The promise when ready.
 */
arc.app.db.idb.open = function() {
  return new Dexie.Promise(function(resolve, reject) {
    var db = new Dexie('arc');
    db.version(1)
      .stores({
        headers: '&[key+type],key,type',
        statuses: '&key',
        historyUrls: '&url',
        historySockets: '&url',
        requestObject: '++id,url,method,[url+method],type,_name',
        serverExportObjects: '[serverId+requestId],serverId,requestId',
        projectObjects: '++id,*requestIds'
      });
    db.version(2)
      .stores({
        headers: '&[key+type],key,type',
        statuses: '&key',
        historyUrls: '&url',
        historySockets: '&url',
        requestObject: '++id,url,method,[url+method],type,_name',
        serverExportObjects: '[serverId+requestId],serverId,requestId',
        projectObjects: '++id,*requestIds',
        variables: '++id,variable,type'
      });
    db.projectObjects.mapToClass(ProjectObject);
    db.serverExportObjects.mapToClass(ServerExportedObject);
    db.requestObject.mapToClass(RequestObject);
    db.historySockets.mapToClass(HistorySocketObject);
    db.historyUrls.mapToClass(HistoryUrlObject);
    db.statuses.mapToClass(HttpStatusObject);
    db.headers.mapToClass(HttpHeaderObject);
    db.variables.mapToClass(MagicVariableObject);
    db.on('error', function(error) {
      console.error('IndexedDB global error', error);
      let pending = arc.app.analytics.sendException('IDB error:: ' + JSON.stringify(error));
      if (pending) {
        window.pendingAnalytics[window.pendingAnalytics.length] = pending;
      }
    });
    db.on('ready', function() {
      if (arc.app.db.idb.upgraded) {
        return;
      }
      arc.app.db.idb._db = db;
      return arc.app.db.idb.populateDatabase(db)
      .then(() => arc.app.db.idb.upgraded = true)
      .catch(() => arc.app.db.idb.upgraded = false);
    });
    db.open()
      .then(function() {
        resolve(db);
      })
      .catch(function(error) {
        console.error('IDB open main catch block', error);
        let pending = arc.app.analytics.sendException('IDB create error::' + JSON.stringify(error));
        if (pending) {
          window.pendingAnalytics[window.pendingAnalytics.length] = pending;
        }
        reject(error);
      });
  });
};
/**
 * Populate database with initial data
 *
 * @return {Promise} Fulfilled promise when data were populated or no population is needed.
 */
arc.app.db.idb.populateDatabase = function(db) {
  //if statuses are set headers must be set as well since they are inserted in single transaction.
  return db.statuses.count()
    .then((count) => {
      if (count > 0) {
        console.info('Database already populated');
        return Dexie.Promise.resolve(null);
      }
      return arc.app.db.idb.downloadDefinitions()
        .catch(function() {
          console.warn('Definitions wasn\'t there. skipping definitions installation.');
          return Dexie.Promise.reject(new Error('Definitions location error'));
        });
    })
    .then(function(defs) {
      if (!defs) {
        return Dexie.Promise.resolve(null);
      }

      defs.requests.forEach((item) => {
        item.type = 'request';
        item.key = item.key.toLowerCase();
      });
      defs.responses.forEach((item) => {
        item.type = 'response';
        item.key = item.key.toLowerCase();
      });
      let headers = defs.requests.concat(defs.responses);

      return db.transaction('rw', db.statuses, db.headers, function() {
        console.info('populating database with predefined values');
        let promises = [];
        let codes = defs.codes;
        codes.forEach(function(item) {
          promises.push(db.statuses.add(item));
        });
        headers.forEach(function(item) {
          promises.push(db.headers.add(item));
        });
        return Dexie.Promise.all(promises);
      });
    })
    .then(function() {
      console.log('The database has been populated with data.');
    })
    .catch(function(e) {
      console.warn('Database population unsuccessfull.', e);
      let pending = arc.app.analytics.sendException('IDB populate error::' + JSON.stringify(e));
      if (pending) {
        window.pendingAnalytics[window.pendingAnalytics.length] = pending;
      }
    });
};
/**
 * Creates IndexedDB key for a RequestObject.
 * The main key is a combination of [HTTP METHOD]:[URL]
 *
 * @param {String} method A HTTP method
 * @param {String} url An URL of the request.
 * @return {String} a key for the Request object
 */
arc.app.db.idb.requests.createRequestKey = function(method, url) {
  var args = Array.from(arguments);
  if (args.length !== 2) {
    throw new Error('Number of arguments requires is 2 but ' + args.length +
      ' has been provided');
  }
  return method + ':' + url;
};
arc.app.db.idb.downloadDefinitions = function() {
  var url = chrome.runtime.getURL ? chrome.runtime.getURL('/assets/definitions.json') :
    '/app/assets/definitions.json'; // for test cases
  return fetch(url)
    .then(function(response) {
      return response.json();
    });
};
/**
 * Get status code definition by it's code
 */
arc.app.db.idb.statuses.getStatusCode = function(code) {
  return arc.app.db.idb.open()
    .then(function(db) {
      return db.statuses.get(code)
        .finally(function() {
          db.close();
        });
    });
};
/**
 * Get header from the storage by it's name and type
 */
arc.app.db.idb.headers.getHeaderByName = function(name, type) {
  return new Promise(function(resolve, reject) {
    arc.app.db.idb.open()
      .then(function(db) {
        let result = null;
        db.headers.where('[key+type]')
          .equals([name, type])
          .each(function(header) {
            result = header;
          })
          .catch(reject)
          .finally(function() {
            db.close();
            resolve(result);
          });
      })
      .catch((e) => reject(e));
  });
};
